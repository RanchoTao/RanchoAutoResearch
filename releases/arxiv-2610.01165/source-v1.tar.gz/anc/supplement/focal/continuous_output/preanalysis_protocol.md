# Preregistration: margin-conditioned continuous-output audit

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Status: **Specified before new outcome acquisition**  
registration date: 2026-09-21  
Experiment: continuous-output audit  
Purpose: validity criterion, not mechanism identification

## 1. Question and scope

This audit tests whether the known longitudinal change in single-block-bypass top-1 disagreement is primarily an argmax-threshold consequence of changing intact decision geometry, or whether its direction is also present in continuous output-space measurements.

The intervention is identity bypass of exactly one interior Transformer block. The endpoint is the response to that intervention on fixed teacher-forced positions. No result will be described as block importance, redundancy, specialization, necessity, task capability, pruning safety, or self-repair.


### Prior-result exposure declaration

Before registration, a pre-existing high-level positive decision was visible, but no quantitative report, table, figure, analysis output or raw metric was inspected. That earlier result is not used as evidence. Definitions were specified before fresh outcome acquisition, but registration was not fully blind to the existence of this prior decision. Definitions followed the preselected protocol and hypothesis map rather than quantitative outcomes.

## 2. Exact cells

### 2.1 Pythia-160M / Hella-derived panel

- Models: `EleutherAI/pythia-160m-seed{1,4,6,7,8,9}`.
- Training-run IDs: 1, 4, 6, 7, 8, 9. These six runs are the replication units.
- Early revision: `step14000`.
- Final revision: `step143000`.
- Exact resolved commits:

| Run | step14000 | step143000 |
|---:|---|---|
| 1 | `d8df939651bec2282b2337cca5cb6fd183ecde9b` | `55b3cacda157ace46fb7f6f5118d79f230fb8158` |
| 4 | `981fd2c0ddc57aff3cbfd87c1445483b5dad0e2c` | `9049ed723bba220b41bae58725f5ee9f221322d1` |
| 6 | `44721b9e1fa46523ea9dcc1ac4dc793d9703ca73` | `cc0bc22203105a63ea46f05c42770961b19d86d3` |
| 7 | `655636b0b77c939bb916bab68d5e999d745f68a7` | `61c1e84bc17e4e117573c35142e2fe7e5f5e81c2` |
| 8 | `b192eef2a91cf18e517fa62ead27c67c23fa53c8` | `495b1616a6a8d724c836e1b7e32db9868329a251` |
| 9 | `e9fb2ace6a46cdb587e89df7a9a26d1ccd9f1952` | `e4c3c2c9bfdc416c1d7445689bc38122a5555ebf` |

- Evaluated blocks: zero-based GPT-NeoX block indices 1 through 10 inclusive. Blocks 0 and 11 are excluded.
- Pilot: run 1, `step14000`, may be executed first. It is implementation evidence only and is excluded from scientific interpretation until the same code/config passes and all twelve Pythia run-checkpoint cells are complete.

### 2.2 OLMo-2 7B / general panel

- Repository: `allenai/OLMo-2-1124-7B`.
- Early revision: `stage1-step93000-tokens391B`; resolved commit `ebee110f42239c33f87b113880d5acd077e45016`.
- Final revision: `stage1-step928646-tokens3896B`; resolved commit `c0371f4281bf2376207646c6b62ddc6c442c7577`.
- Tokenizer revision for both: `ebee110f42239c33f87b113880d5acd077e45016`.
- Evaluated blocks: zero-based block indices 1 through 30 inclusive. Blocks 0 and 31 are excluded.
- Evidential role: one released trajectory used as a generalization/counterexample cell, not an independent-seed replication.

No checkpoint, run, corpus, or model substitution is allowed. A missing exact artifact stops the affected panel and is reported as missing.

## 3. prespecified text and token contract

### 3.1 Pythia Hella-derived text

- Source: the existing historical HellaSwag validation correct-continuation derived text.
- Derived-text SHA-256: `EF75B67A0F3A316B6D465295E2DD58314738FD0E38BCF01790DBA7022C35468E`.
- Window manifest SHA-256: `39055C86EDD2A23B1A014E20695237D5CBA3B0DB90FAF5A494AD32577FE374C1`.
- Window manifest: 18 rows, evaluation seeds 11, 23, and 37; six windows per evaluation seed.
- Each window contains 257 token IDs. The first 256 are inputs and the following 256 next-token IDs are labels, producing 4,608 evaluated positions per block per run-checkpoint cell.
- Token spans and per-window token-ID SHA-256 values must match the existing manifest exactly after tokenization. No special token is added.

### 3.2 OLMo-2 7B general text

- prespecified context manifest SHA-256: `96B0D8AD62C378E32BFDBC364E43BCEA3BD7B26C0DE332F9FE4A35219CD68F4D`.
- Source-text SHA-256 recorded in that manifest: `9e9fa1ad55b1c2c95b08e37dd8e653f638fac2c6de904b79e813611eefbc985f`.
- The manifest contains 18 windows, each with 257 materialized token IDs and its own SHA-256, yielding 4,608 evaluated positions per block per checkpoint.
- The manifest token IDs are used directly. They are not reselected or retokenized.

### 3.3 Inclusion and exclusion

- Include all 256 next-token positions in every one of the 18 windows for every evaluated block.
- There is no padding mask because every prespecified window has equal length and all positions are real tokens.
- Do not exclude low-margin, incorrect, high-entropy, punctuation, repeated, or special-looking tokens.
- A nonfinite logit, log probability, entropy, KL component, JS component, target NLL, or derived metric is a numerical criterion failure for the entire cell; it is not silently dropped.
- Duplicate contextual positions across windows, if any, remain because the prespecified manifests define the evaluation sample.

## 4. Inference and numerical precision

- Models run in `eval()` and `torch.inference_mode()` with `use_cache=False`.
- Model weights/inference dtype: FP16 for Pythia-160M and OLMo-2 7B, matching their existing canonical assays.
- No quantization, adaptation, compilation, or stochastic decoding.
- All output logits are immediately cast to FP32 before argmax, top-k, log-softmax, probability, entropy, KL, JS, logit-margin, and NLL extraction.
- The intact logits are computed once per batch and reused for all block comparisons in that batch.
- Identity bypass passes a block's residual input through as its output using the existing architecture-specific harness. Alpha=0/no-op and alpha=1/exact-bypass equivalence criteria are required where the harness exposes graded attenuation.
- Argmax uses `torch.argmax` on FP32 logits, hence the lowest token index among exact maxima.

## 5. Per-token × block record

Each output row corresponds to one model, training run (or OLMo trajectory), checkpoint, evaluation window, within-window prediction position, and bypassed block. Lossless Parquet is the primary record format. Integer IDs remain integer; all metric columns are stored as float64 after FP32 extraction/accumulation values are transferred to CPU.

Required identifiers:

- panel, repository, training run, checkpoint/revision, resolved model commit, tokenizer revision;
- evaluation seed, sequence index, token start if supplied by the manifest, within-window position, target token ID, block index;
- context-manifest SHA-256 and acquisition/config hashes.

Required intact quantities:

- intact top-1 token ID `a`;
- intact runner-up token ID `b` from FP32 logits with deterministic index tie breaking;
- intact logits `z_a` and `z_b`;
- intact logit margin `m = z_a - z_b`;
- intact maximum probability `p_a`;
- intact entropy;
- intact target-token log probability and NLL.

Required bypass quantities:

- bypass top-1 token ID;
- bypass target-token log probability and NLL;
- bypass logits at the fixed intact tokens `a` and `b`;
- sufficient scalar components to recompute exact forward KL and JS from the acquisition output: intact and bypass log-normalizers, the forward-KL expectation terms, and the two JS half-divergence terms. Full vocabulary distributions are not saved because the exact scalar sufficient components and derived metrics are retained per token.

Required derived quantities:

- top-1 flip indicator;
- forward KL;
- Jensen-Shannon divergence;
- target-token NLL change;
- logit-margin loss.

No additional scientific endpoint will be introduced after this registration. Probability normalization residuals and identity-distribution KL/JS are QC diagnostics, not scientific endpoints.

## 6. Fixed metric definitions

Let intact logits be `z`, bypass logits be `z'`, `p = softmax(z)`, `q = softmax(z')`, target token `y`, intact top-1 token `a`, and intact runner-up `b`. Natural logarithms are used throughout; entropy and divergences are in nats.

### 6.1 Intact margin

`margin = z[a] - z[b]`, where `a` and `b` are the largest and second-largest FP32 intact logits with lower token ID breaking exact ties. This is a logit margin, not a probability margin.

### 6.2 Maximum probability and entropy

- `max_probability = p[a]`.
- `entropy = -sum_v p[v] * log p[v]`, evaluated from FP32 `log_softmax`; the limiting value `0 log 0 = 0` applies.

### 6.3 Forward KL — preregistered primary continuous metric

`KL_forward = KL(p || q) = sum_v p[v] * (log p[v] - log q[v])`.

This direction is fixed. Reverse or symmetric KL will not replace it.

### 6.4 Jensen-Shannon divergence

Let `r = (p + q) / 2`. Then

`JS = 0.5 * KL(p || r) + 0.5 * KL(q || r)`.

It is computed stably with `log r = logaddexp(log p, log q) - log(2)` in FP32. Both half-divergence terms are retained.

### 6.5 Logit-margin loss

The competitor is fixed from the intact distribution:

`logit_margin_loss = (z[a] - z[b]) - (z'[a] - z'[b])`.

Positive values mean the bypass erodes the intact top-1 token's logit advantage over its strongest intact competitor. The competitor is not reselected under bypass.

### 6.6 Target-token NLL change

`target_nll_change = (-log q[y]) - (-log p[y]) = log p[y] - log q[y]`.

Positive values mean higher teacher-forced target-token NLL under bypass.

### 6.7 Top-1 disagreement

`flip = 1[argmax(z) != argmax(z')]` using the same FP32 lowest-index argmax rule for both paths.

## 7. Numerical and reproduction criteria

All criteria are evaluated before full scientific analysis.

1. **Repeated-intact determinism:** two intact forward passes on the pilot batch must have identical top-1 and runner-up IDs and maximum absolute FP32-logit difference `<= 1e-5`.
2. **Probability validity:** all probabilities/log probabilities and metrics finite; per-token probability sums satisfy absolute error `<= 1e-5` from one for both intact and bypass paths.
3. **Divergence nonnegativity:** forward KL, both JS half terms, and JS must be `>= -1e-6`. Values in `[-1e-6, 0)` are retained raw and clamped to zero only in presentation summaries; values below `-1e-6` fail the cell.
4. **Identical-distribution sanity:** comparing intact log probabilities with themselves must yield absolute forward KL and JS `<= 1e-6` for every pilot token.
5. **Canonical disagreement reproduction:** for OLMo, intact and bypass top-1 arrays must exactly equal the saved canonical token-decision arrays. For Pythia, disagreement integer counts must exactly reproduce every available historical evaluation-seed × layer alpha=1 count at the two checkpoints. The aggregate must therefore reproduce the known canonical panel values without tolerance beyond displayed rounding. Any mismatch stops before interpretation.
6. **Manifest cardinality:** exactly 18 windows, 257 token IDs per window, 4,608 evaluated positions per block, and exactly the preregistered block list. Every Pythia token hash and every OLMo materialized token-ID hash must match its prespecified manifest.
7. **Bypass harness:** no-op output equals intact output within `1e-5`, exact bypass equals literal deletion/identity behavior within `1e-5` where the existing harness supports this check, every requested block executes exactly once, and no nonrequested block is skipped.

A failed criterion halts the affected panel. The failure is diagnosed and recorded, but scientific endpoint analysis is not performed on a partially failed panel. Corrections to implementation bugs are permitted only if the preregistered definitions remain unchanged; code revisions and repeated criterion attempts are logged.

## 8. Aggregation hierarchy

The raw unit is token × block, but tokens and blocks are repeated measurements, not training replications.

### Pythia

1. Compute token means within each prespecified window and block.
2. Average the 18 window means with equal window weight within run × checkpoint × block. Equal lengths make this equal to the token-weighted mean, but the window-first route is retained explicitly.
3. Average the ten block means with equal block weight to obtain a run × checkpoint mean.
4. Compute paired final-minus-early changes within each of the six runs.
5. Average run changes with equal run weight for the panel estimate.

Layer profiles average the six run-specific layer estimates with equal run weight. No token-level standard error is presented as replication uncertainty.

### OLMo-2 7B

The same window-first and equal-block aggregation is used, but there is only one trajectory. Checkpoint contrasts are descriptive. A paired 18-window bootstrap may quantify evaluation-window variation and must be labeled as such, never as independent-training uncertainty.

## 9. Uncertainty

### Pythia primary uncertainty

- Use the existing paired training-run bootstrap convention: resample the six whole training runs with replacement, retain the early/final pair and every layer/window within a sampled run, and recompute the statistic.
- Use 100,000 bootstrap draws with seed `20260828` for aggregate endpoint changes and the five primary margin-stratum contrasts.
- Report percentile 95% intervals.
- Token/window variation may be tabulated descriptively but is not substituted for run uncertainty.

### Layer profiles

- Layer-specific early/final means and changes use the same paired whole-run bootstrap with 100,000 draws.
- Cross-metric profile association is reported as Spearman correlation across the ten layer-level changes and normalized-profile RMSE. These ten layers are repeated structure, not independent training replications; no layer-based inferential p-value is used.

### OLMo-2 7B

- Report point estimates for the single trajectory.
- For figure uncertainty only, use 10,000 paired bootstrap resamples of the 18 prespecified windows with seed `20260921`, retaining each window's early/final pair and all blocks. Label intervals “window-bootstrap variation.”

## 10. Margin stratification

Strata are fixed without using bypass outcomes.

### Pythia

- Pool the unique intact token positions from all six runs at `step14000`; each token position contributes once per run, not once per block.
- Compute the 20th, 40th, 60th, and 80th percentiles of the pooled early intact logit-margin distribution using NumPy's default linear quantile definition.
- These four cutpoints define five fixed strata `[min,q20)`, `[q20,q40)`, `[q40,q60)`, `[q60,q80)`, and `[q80,+inf]` for both checkpoints and all six runs.
- Exact boundary values enter the higher stratum, except the maximum remains in the final stratum.
- If quantile ties produce duplicate cutpoints, do not alter the number or location after seeing bypass outcomes. Report the duplicate and treat any resulting empty stratum as a preregistered missing stratum; an empty stratum makes the criterion inconclusive pattern rather than continuous-effect criterion or threshold-based explanation criterion.

### OLMo-2 7B

- Define a separate five-stratum reference from the unique intact tokens at the early OLMo checkpoint using the same quantile rule.
- Apply those cutpoints unchanged to early and final OLMo checkpoints.

Within each stratum, use the aggregation and uncertainty hierarchy above for top-1 disagreement and each continuous metric. Bins are not defined separately by checkpoint.

“Most strata” is fixed as at least four of five strata.

## 11. Smooth margin adjustment

This is descriptive adjustment, not a causal model.

### Pythia binary response model

Fit a binomial logistic generalized linear model to per-token × block flip indicators:

`flip ~ checkpoint_final + bs(intact_margin, df=5, degree=3, include_intercept=False) + C(block) + C(run)`.

- The spline boundary knots are the minimum and maximum of the pooled Pythia early-reference margin distribution; internal knots use its 25th, 50th, and 75th percentiles.
- Margins outside the early range at the final checkpoint are clipped to the early minimum/maximum for spline evaluation, and the clipped fraction is reported.
- Report the checkpoint coefficient, adjusted odds ratio, and cluster-robust 95% interval with training run as the cluster. With only six clusters, this interval is explicitly labeled small-cluster/descriptive.
- Robustness: refit six times leaving out one run and report the range of checkpoint coefficients. No alternative spline degrees or transformations are tried.

### Pythia continuous responses

For forward KL, JS, target NLL change, and logit-margin loss, fit separate ordinary least-squares models with the same fixed design:

`metric ~ checkpoint_final + bs(intact_margin, df=5, degree=3, include_intercept=False) + C(block) + C(run)`.

Use run-clustered covariance and the same leave-one-run-out coefficient range. Coefficients are descriptive checkpoint associations after margin adjustment.

### OLMo-2 7B

Fit the same models without `C(run)` and report coefficients only; do not report a training-replication confidence interval. A window fixed effect is not included because window identity and token margin are highly structured; the paired window bootstrap supplies descriptive variation.

## 12. Continuous endpoint and layer-profile analyses

For each block and checkpoint estimate mean:

- top-1 disagreement;
- forward KL (primary continuous metric);
- JS;
- target-token NLL change;
- logit-margin loss.

For Pythia, compute each run's early/final mean and paired change before averaging across runs. Report the six run changes.

For each metric quantify layer-structure agreement by:

1. Spearman correlation between early and final ten-layer profiles;
2. Spearman correlation between the ten layerwise early-to-final changes for top-1 disagreement and for each continuous metric;
3. normalized-profile RMSE between early and final profiles after division by each checkpoint's layer mean, only when that mean is positive and finite;
4. sign concordance: fraction of layers whose early-to-final change has the same sign as the panel-level change.

If a metric mean is nonpositive, normalized-profile RMSE for that metric is undefined and reported as such; it is not repaired by shifting values.

## 13. Fixed scientific interpretation rule

The preregistered primary continuous metric is forward KL.

### continuous-effect criterion

The continuous-output evidence meets the primary criterion only if both conditions hold for Pythia:

1. The equal-run-weight final-minus-early forward-KL change is positive and its paired whole-run bootstrap 95% interval excludes zero on the positive side, matching the known positive direction of top-1 disagreement.
2. The final-minus-early top-1 disagreement contrast is positive and its paired whole-run bootstrap 95% interval excludes zero in at least four of the five fixed early-reference intact-margin strata.

JS, target NLL change, logit-margin loss, smooth adjustment, layer profiles, and OLMo are required corroborating/diagnostic analyses but cannot replace failure of either primary continuous-effect criterion condition.

### threshold-based explanation criterion

threshold-based explanation criterion structural-sensitivity interpretations if all of the following hold:

1. Pythia top-1 disagreement has the known positive aggregate change;
2. the Pythia forward-KL point change is nonpositive or its paired-run 95% interval includes zero, and neither JS nor logit-margin loss has a positive paired-run 95% interval excluding zero;
3. at most two of five fixed margin strata have a positive top-1 contrast with paired-run 95% interval excluding zero; and
4. the smooth-adjusted Pythia checkpoint coefficient for flip is nonpositive or its run-clustered 95% interval includes zero, with no stable positive sign across all six leave-one-run-out fits.

Under threshold-based explanation criterion, the result is interpreted as evidence that the observed top-1 pattern can be accounted for by evolving decision-boundary geometry under the specified tests. This outcome would not justify interpreting top-1 disagreement alone as structural sensitivity.

### inconclusive pattern

Every outcome not satisfying the complete continuous-effect criterion or complete threshold-based explanation criterion rule is inconclusive pattern. Empty preregistered strata, incomplete required cells, conflicting continuous metrics, positive aggregate KL without margin-stratum persistence, or stratum persistence without positive aggregate KL are inconclusive pattern. The verdict is never forced by OLMo because OLMo is a single released trajectory.

## 14. Missing data and failures

- Do not substitute checkpoints, model runs, windows, blocks, or corpora.
- A missing weight snapshot, tokenizer snapshot, context asset, or canonical comparison artifact is named explicitly in the QC report.
- A required Pythia run missing either checkpoint prevents the six-run primary criterion and yields inconclusive pattern/incomplete, not a five-run replacement analysis.
- A missing OLMo cell does not change the Pythia criterion but is reported as incomplete generality evidence.
- Failed or preempted jobs may be rerun with the identical prespecified config. Attempts, job IDs, exit codes, logs, and hashes are retained.
- Implementation bugs may be corrected only when the scientific definitions above remain unchanged. Each code change receives a new hash and a written reason before rerun.
- No scientific analysis begins until every numerical and reproduction criterion passes for all required cells.

## 15. Fixed outputs

- Per-token × block lossless Parquet records, partitioned by panel/run/checkpoint.
- Cell metadata and QC JSON.
- Layer/checkpoint summary CSV.
- Pythia run-level change CSV.
- Margin-stratum summary CSV with the fixed cutpoints.
- Smooth-model coefficient CSV and leave-one-run-out CSV.
- Layer-profile comparison CSV.
- One two-row main figure:
  - row 1: flip probability versus the five fixed intact-margin strata for early/final checkpoints, with Pythia whole-run bootstrap intervals and OLMo window-bootstrap intervals clearly distinguished;
  - row 2: layerwise paired early-to-final changes for top-1 disagreement, forward KL, JS, and logit-margin loss, with Pythia and OLMo separated.
- QC report, results report distinguishing measurements, interpretation and unresolved hypotheses, and explicit scientific interpretation decision.


