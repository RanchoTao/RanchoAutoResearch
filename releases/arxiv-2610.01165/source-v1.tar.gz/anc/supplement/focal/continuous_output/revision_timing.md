# The numerical reproducibility revision acceptance record

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Timestamp: 2026-09-21  
Revision adopted before fresh outcome acquisition.  
Prespecified environment: `PyTorch 2.11.0 / CUDA 12.8 / Transformers 4.56.2 / L40 / FP16 / batch 2`

## Reason and evidence

The original exact cross-environment top-1 integer-count criterion failed despite exact
semantic/protocol identity and literal bypass equivalence. The numerical-reproduction diagnostic classified
the discrepancy as numerical-boundary instability: documented runtime changes
moved only near-tied argmax decisions, while the closest historical software stack
still did not reproduce every archived integer count. Historical token-level logits
were not archived, so exact historical switch identities cannot be reconstructed.

The numerical reproducibility revision replaces only that nonportable cross-environment equality test with
a binary16-representation-derived ambiguity envelope, exact current-stack
determinism, a sentinel-backend stability check, and per-cell historical-count
compatibility. The one-ULP definition does not contain an observed discrepancy or
a fitted tolerance. Quarantined QC diagnostics validated the fixed definition:
30/30 count intervals included their historical counts, with zero unexplained
residual, and no same-version default/eager switch occurred outside the envelope.

## Exact clause changed

Only the parent preregistration's requirement that every Pythia historical
seed×block disagreement count be reproduced as the same integer across execution
environments is replaced. The operative replacement is
`reproducibility_revision.md`, Sections 3–6.

## Clauses unchanged

Models, runs, checkpoints, prespecified text windows, evaluated blocks, token rules,
metric definitions, FP32 metric extraction, primary forward-KL endpoint, margin
stratification, smooth adjustment, aggregation hierarchy, bootstrap procedures,
layer-profile comparisons, scientific missing-data handling, and scientific interpretation
rules remain verbatim as prespecified in the parent preregistration. Exact semantic and
protocol identity is not relaxed. All non-canonical numerical criteria remain.

## Temporal independence

No scientific endpoint from the continuous-output study, longitudinal contrast, margin-stratified
result, or prior quantitative report was inspected in accepting this amendment.
Only the numerical-reproduction diagnostic QC artifacts were used. New scientific acquisition is required
from scratch after the amended pilot passes; quarantined outputs are excluded.

## Cryptographic provenance

- Original preregistration SHA-256:
  `DF092F728B8ED845CBA6F4460137D46955F8EB12941E5D5EEC3F4F5C18EB62D6`.
- Proposed amendment SHA-256:
  `7E99D4C87CD609A677C9423DB016A6EBA296B060D77D62A3C45156C271D01A7C`.
- Rescue protocol SHA-256:
  `50C0311D603768E281A7171D6998785EC5BF42A0824DD5064BB71F4E59728BDD`.

The original preregistration and proposal remain immutable. This acceptance record
and the implementation specification are append-only after their registration hashes are
written.

