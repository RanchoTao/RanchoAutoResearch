# Pre-analysis implementation clarifications

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Specified before any scientific outcome inspection: 2026-09-21.

The parent preregistration is unchanged. These are deterministic resolutions of
implementation details, not endpoint or decision-rule changes.

1. The smooth-model section simultaneously writes `bs(..., df=5, degree=3)` and
   explicitly fixes three internal knots at the early-reference 25th, 50th, and
   75th percentiles. A cubic B-spline with three fixed internal knots and no
   spline intercept has six columns, so the two statements cannot both hold.
   The implementation prioritizes the explicitly fixed knot locations and uses
   the resulting six non-intercept cubic B-spline columns. This resolution is
   prespecified before outcome inspection. Smooth models are diagnostic and cannot
   supply the continuous-effect criterion criterion.
2. Run-clustered sandwich intervals use the conventional CR1 correction
   `G/(G-1) * (N-1)/(N-K)` and a normal `1.96` multiplier. They remain labeled
   small-cluster/descriptive, as preregistered.
3. Quantile assignment uses NumPy `searchsorted(cutpoints, margin, side='right')`,
   placing exact cutpoint values in the higher stratum.
4. A stratum mean follows the prespecified window-first hierarchy: token means inside
   each available window×block×stratum, then equal window means, equal block
   means, and finally equal run means. An empty required stratum is missing and
   forces inconclusive pattern as specified.
5. Numerical-ambiguity sensitivity is descriptive only. Primary deterministic
   disagreement retains every row. Lower/upper robustness values set ambiguity-
   eligible flips to 0/1, respectively, under the prespecified one-ULP rule.

