# QC report — the numerical reproducibility revision the continuous-output study

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Overall: **PASS**

## Pilot and amended canonical criterion

- Exact current-environment determinism: `True`.
- Historical count intervals passing: 30/30.
- Unexplained historical residual: 0.
- Sentinel switches: 7 intact and 68 bypass; outside the union envelope: 0 and 0.
- The historical exact-count failure is attributable to FP16 near-tie argmax instability under runtime changes, not data/protocol drift.

## Full cells

| Cell | Complete | Rows | Max probability residual | Minimum raw divergence | criterion |
|---|---:|---:|---:|---:|---|
| pythia_seed1_step14000 | True | 46080 | 9.5367431640625e-07 | 1.2853614862251561e-05 | PASS |
| pythia_seed1_step143000 | True | 46080 | 8.344650268554688e-07 | 5.031168620917015e-05 | PASS |
| pythia_seed4_step14000 | True | 46080 | 8.344650268554688e-07 | 1.3133822903910186e-05 | PASS |
| pythia_seed4_step143000 | True | 46080 | 8.344650268554688e-07 | 1.851946217357181e-05 | PASS |
| pythia_seed6_step14000 | True | 46080 | 1.0728836059570312e-06 | 6.8232061494200025e-06 | PASS |
| pythia_seed6_step143000 | True | 46080 | 8.344650268554688e-07 | 2.3106986191123724e-05 | PASS |
| pythia_seed7_step14000 | True | 46080 | 8.344650268554688e-07 | 1.4137850484985393e-05 | PASS |
| pythia_seed7_step143000 | True | 46080 | 9.5367431640625e-07 | 3.397572800167836e-05 | PASS |
| pythia_seed8_step14000 | True | 46080 | 7.152557373046875e-07 | 5.721587967855157e-06 | PASS |
| pythia_seed8_step143000 | True | 46080 | 8.344650268554688e-07 | 2.8455320716602728e-05 | PASS |
| pythia_seed9_step14000 | True | 46080 | 9.5367431640625e-07 | 1.6299117078233394e-06 | PASS |
| pythia_seed9_step143000 | True | 46080 | 8.344650268554688e-07 | 2.3695729396422394e-06 | PASS |
| olmo7b_stage1_step93000_tokens391B | True | 138240 | 1.3113021850585938e-06 | 1.7167221244562825e-07 | PASS |
| olmo7b_stage1_step928646_tokens3896B | True | 138240 | 1.1920928955078125e-06 | 1.5300777533866494e-07 | PASS |

## Failures

None.

All cells use exactly 18 prespecified windows, 257 token IDs per window, 4,608 evaluated positions per block, and the predeclared interior block lists. Probability/KL/JS, identical-distribution, repeated-forward, bypass-equivalence, manifest, and amended canonical criteria are encoded in each cell's `qc.json` and `harness_qc.json`.
