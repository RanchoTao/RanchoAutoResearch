# Results: margin-conditioned continuous-output audit

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Preregistered classification: **continuous-effect criterion**.

This report tests metric validity and narrows mechanism hypotheses. It does not identify a mechanism.

## Results

All 12 Pythia cells and both exact OLMo-2 7B cells completed their prespecified acquisition and QC criteria. OLMo used the separately prespecified, historically recovered canonical stack (PyTorch 2.6.0 / Transformers 4.51.3); Pythia remained in the numerical reproducibility revision stack. This architecture-specific execution difference is documented and OLMo is interpreted only as one descriptive released trajectory.

### Continuous endpoints

| Panel | Endpoint | Early | Final | Final − early | 95% interval |
|---|---|---:|---:|---:|---:|
| pythia_hella | flip | 0.289927 | 0.369144 | 0.0792173 | [0.0677083, 0.0880896] |
| pythia_hella | forward_kl | 0.326652 | 0.575899 | 0.249248 | [0.219401, 0.272192] |
| pythia_hella | js | 0.0722693 | 0.121588 | 0.049319 | [0.0435091, 0.0537097] |
| pythia_hella | target_nll_change | 0.349957 | 0.599783 | 0.249826 | [0.223395, 0.271032] |
| pythia_hella | logit_margin_loss | 0.21133 | 0.317936 | 0.106606 | [0.0791849, 0.129208] |
| olmo7b_general | flip | 0.145681 | 0.131076 | -0.014605 | single trajectory |
| olmo7b_general | forward_kl | 0.105064 | 0.0781675 | -0.026896 | single trajectory |
| olmo7b_general | js | 0.0232873 | 0.0179886 | -0.0052987 | single trajectory |
| olmo7b_general | target_nll_change | 0.101152 | 0.0698441 | -0.0313074 | single trajectory |
| olmo7b_general | logit_margin_loss | 0.0407047 | 0.0132609 | -0.0274438 | single trajectory |

For Pythia, intervals resample the six paired training runs. For OLMo-2 7B, changes are descriptive for one released trajectory.

Pythia run-level final-minus-early changes:

| Run | Flip | Forward KL | JS | Target NLL | Logit-margin loss |
|---:|---:|---:|---:|---:|---:|
| 1 | 0.052908 | 0.182644 | 0.0359045 | 0.191485 | 0.0463999 |
| 4 | 0.0915148 | 0.274677 | 0.0539239 | 0.262785 | 0.127555 |
| 6 | 0.0786024 | 0.266006 | 0.0507414 | 0.270148 | 0.129771 |
| 7 | 0.0828342 | 0.270351 | 0.0532211 | 0.267796 | 0.0881634 |
| 8 | 0.0920356 | 0.274039 | 0.055224 | 0.277658 | 0.140406 |
| 9 | 0.0774089 | 0.22777 | 0.0468989 | 0.229085 | 0.107341 |

### Margin conditioning

Positive Pythia flip contrasts with paired-run intervals excluding zero: **5/5**.

| Stratum | Early flip | Final flip | Change | Paired-run 95% interval |
|---:|---:|---:|---:|---:|
| Q1 | 0.585853 | 0.615959 | 0.0301067 | [0.0191479, 0.043713] |
| Q2 | 0.417016 | 0.525898 | 0.108882 | [0.0899704, 0.127481] |
| Q3 | 0.254504 | 0.371716 | 0.117212 | [0.107165, 0.12678] |
| Q4 | 0.139863 | 0.234473 | 0.0946105 | [0.0759918, 0.109933] |
| Q5 | 0.0521739 | 0.107795 | 0.0556214 | [0.0480421, 0.0632109] |

The smooth margin-adjusted Pythia flip checkpoint coefficient was 0.470621 (descriptive run-clustered 95% interval [0.4023, 0.538943]; odds ratio 1.60099). Leave-one-run-out coefficients ranged from 0.453362 to 0.501696. The interval is explicitly small-cluster/descriptive.

### Numerical-boundary robustness

Ordinary deterministic disagreement is the primary endpoint; ambiguity-eligible rows were not removed. The table below gives its representation-derived lower/upper envelope.

| Panel | Checkpoint | Deterministic flip | Stable-only lower | Ambiguity-allowed upper | Ambiguous fraction |
|---|---|---:|---:|---:|---:|
| olmo7b_general | stage1-step928646-tokens3896B | 0.131076 | 0.12997 | 0.131612 | 0.00164207 |
| olmo7b_general | stage1-step93000-tokens391B | 0.145681 | 0.145001 | 0.146166 | 0.00116464 |
| pythia_hella | step14000 | 0.289927 | 0.278053 | 0.296181 | 0.0181279 |
| pythia_hella | step143000 | 0.369144 | 0.173535 | 0.484426 | 0.31089 |

The amended pilot had exact within-stack repeatability. All 30 historical seed×block counts lay in their one-ULP admissible intervals with zero residual. The sentinel changed 7 intact and 68 bypass identities, with zero switches outside the union ambiguity envelope. The earlier exact-count failure therefore arose from FP16 near-tie argmax instability, not semantic data/protocol drift.

### Layer-profile quantification

| Panel | Metric | Early/final Spearman | Change vs flip Spearman | Normalized RMSE | Sign concordance |
|---|---|---:|---:|---:|---:|
| pythia_hella | flip | 0.90303 | 1 | 0.0987423 | 1 |
| pythia_hella | forward_kl | 0.890909 | 0.636364 | 0.306088 | 1 |
| pythia_hella | js | 0.915152 | 0.769697 | 0.308831 | 1 |
| pythia_hella | target_nll_change | 0.878788 | 0.6 | 0.329733 | 1 |
| pythia_hella | logit_margin_loss | 0.430303 | 0.212121 | 0.540278 | 1 |
| olmo7b_general | flip | 0.784602 | 1 | 0.337119 | 0.533333 |
| olmo7b_general | forward_kl | 0.786874 | 0.873637 | 1.15023 | 0.4 |
| olmo7b_general | js | 0.766407 | 0.902113 | 1.02636 | 0.4 |
| olmo7b_general | target_nll_change | 0.705451 | 0.696107 | 1.25977 | 0.5 |
| olmo7b_general | logit_margin_loss | 0.547052 | 0.254727 | 3.16743 | 0.8 |

## Interpretation

- A pure or dominant argmax-threshold account (H8/U4) is weakened for the replicated Pythia result: the primary continuous endpoint moves in the same direction and disagreement remains positive within at least four fixed margin strata.
- The audit supports treating the Pythia longitudinal response as more than a changing intact-margin threshold effect. It does not distinguish local perturbation magnitude (H1), suffix transfer (H2), their combination (H3), or direction alignment (H9).
- The OLMo-2 7B result remains a single-trajectory generalization/counterexample cell and cannot establish cross-family replication.

## Unresolved interpretations

- H1, H2, H3, H4, and H9 remain live candidates requiring the matched-perturbation study-style local/suffix decomposition; none is identified here.


No block is described here as important, redundant, specialized, or required. No claim of mechanism identification is made.
