# The numerical reproducibility revision: implementation specification for the canonical QC criterion

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Specified: 2026-09-21  
Status: **Adopted before fresh outcome acquisition**  
Scope: canonical historical reproduction QC only  
Parent preregistration SHA-256: `DF092F728B8ED845CBA6F4460137D46955F8EB12941E5D5EEC3F4F5C18EB62D6`  
Proposed amendment SHA-256: `7E99D4C87CD609A677C9423DB016A6EBA296B060D77D62A3C45156C271D01A7C`

## 1. Unchanged requirements

Every semantic and protocol object remains an exact invariant: ordered token IDs,
targets, evaluated indices, window order, attention masks, position semantics,
checkpoint repository, revision and resolved commit, model configuration, tokenizer
mapping, evaluated block IDs, and whole-block bypass semantics. A mismatch in any
one of these objects fails the criterion and cannot be classified as numerical ambiguity.

All original probability, divergence, repeated-forward, bypass-equivalence,
manifest, window, and token-count criteria also remain in force. This amendment does
not alter a scientific cell, metric, primary metric, analysis, uncertainty method,
aggregation hierarchy, or scientific interpretation criterion.

## 2. prespecified execution stack

Environment identifier: `PyTorch 2.11.0 / CUDA 12.8 / Transformers 4.56.2 / L40 / FP16 / batch 2`.

- Python 3.12.4; PyTorch 2.11.0+cu128; CUDA runtime 12.8; cuDNN 9.1.9.
- Transformers 4.56.2; tokenizers 0.22.1; NumPy 2.5.2;
  safetensors 0.8.0; PyYAML 6.0.3; pyarrow 21.0.0.
- One NVIDIA L40 (48 GB); no multi-GPU execution.
- Model weights use FP16. Metric extraction and accumulation use FP32 as in the
  parent preregistration. Autocast is disabled.
- Batch size is 2. `torch.backends.cuda.matmul.allow_tf32=False` and
  `torch.backends.cudnn.allow_tf32=False`. Deterministic algorithms are enabled.
- Pythia production attention is explicitly `sdpa`. OLMo production attention is
  explicitly `eager`, preserving its prespecified canonical implementation. Pythia
  pilot sentinel attention is explicitly `eager`; sentinel results are QC-only.
- No output from the failed or rescue pilots may be reused as scientific data.

## 3. Binary16 spacing and ambiguity

For a top-two decision with FP32-extracted logits `z1 >= z2`, define

`s = float16(max(abs(z1), abs(z2)))`

and

`ulp16 = float32(nextafter(s, +infinity, dtype=float16) - s)`.

The margin is computed in FP32 from the extracted logits:
`m = float32(z1) - float32(z2)`. A decision is boundary-ambiguous exactly when
`m <= ulp16`. A token×block intervention decision is ambiguity-eligible when
either its intact decision or its bypass decision is boundary-ambiguous. No
empirical decimal tolerance, observed discrepancy, backend-switch magnitude, or
historical count enters this definition.

Nonfinite logits, a negative margin below the parent floating-point tolerance, an
overflowed spacing, or an invalid top-two ordering is a numerical failure, not an
ambiguous decision.

## 4. Current-environment determinism

The seed-1/step-14k pilot is acquired twice from separate fresh processes under
the prespecified production configuration. Ordered intact and bypass top-1 IDs and all
FP32-extracted top-two logits must be bitwise identical; maximum absolute logit
difference must be exactly zero. Failure stops the continuous-output study.

## 5. Sentinel-backend check

The same pilot cell is acquired under the predeclared Pythia `eager` sentinel.
Compare production and sentinel top-1 identities. Every intact or bypass identity
switch must be ambiguity-eligible under at least one of the two environments,
using the rule in Section 3. Any switch outside the union envelope fails the criterion.
The sentinel acquisition is never scientific input.

## 6. Historical-count compatibility

For each of the 30 archived evaluation-seed (`11`, `23`, `37`) × block (`1`–`10`)
cells, let `A` be the ambiguity-eligible positions in the production pilot and
let `F_stable` be the number of production flip indicators outside `A`. The exact
admissible interval is

`[F_stable, F_stable + |A|]`.

The archived historical count must lie inside this closed integer interval. The
QC table must report current deterministic count, historical count, `|A|`, both
interval endpoints, pass/fail, and unexplained residual. Any positive residual or
any failed cell stops the continuous-output study. Ambiguous rows remain in all primary analyses;
this rule is a robustness diagnostic, not filtering.

## 7. Pre-acceptance validation provenance

The fixed rule was mechanically checked against quarantined the numerical-reproduction diagnostic QC
arrays before acceptance. It covered 30/30 historical cells with zero unexplained
residual. In the same-version default-versus-eager rescue pair, all 92 flip
switches and all 68 bypass top-1 identity switches were within the primary
one-ULP envelope; none occurred outside it. Validation artifacts:

- the pre-revision validation table (retained outside this export), SHA-256
  `1C6BA23769FCC71D182DCB81D8D207C140D5E6FEAB02D05FD3357159339F0FE6`;
- the pre-revision validation summary (retained outside this export), SHA-256
  `3FEDE2AF258F053598D059011C5A89E0E68586876BE72B7C32AAE35222B01793`.

These rescue outcomes validate but do not define or tune the one-spacing rule.

