# Controlled-study protocols and summaries

| Study | Interpretation | Protocol and evidence |
|---|---|---|
| Continuous-output audit | Training effects persist in continuous output metrics and fixed-margin strata. | `continuous_output/preanalysis_protocol.md`, `implementation_notes.md`, `reproducibility_revision.md`, `revision_timing.md`, `numerical_validation.md`, `results.md`, and `processed/` within that directory |
| Matched perturbations | Local missing-update magnitude and matched downstream response have opposing pooled changes in Pythia, with scale dependence. | `matched_perturbations/preanalysis_protocol.md`, `protocol_revision.md`, validation records, `results.md`, and `processed/` |
| Direction controls | Propagation depends on depth and control family; the joint criterion for targeted compensation is not met. | `direction_controls/preanalysis_protocol.md`, validation records, `results.md`, and `processed/` |

The continuous-output protocol's original exact cross-environment count requirement was replaced before fresh scientific outcome acquisition by the representation-derived criterion in `continuous_output/reproducibility_revision.md`. The original clause is retained to make the change inspectable. `revision_timing.md` records its timing, and the protocol discloses prior exposure to a high-level positive decision without quantitative outcomes. The matching protocol incorporates actual post-cast perturbation magnitudes following a halted matching pilot. No pilot outputs are substituted for the completed scientific measurements.

Historical Hella replication (Figure 11) and the continuous-output audit (Figure 5) have separate numerical sources: `../../source/data/historical/replicated_deltas.csv` and `continuous_output/processed/endpoint_change_summary.csv`, respectively.

These are reader-oriented transcriptions, not new preregistrations. Scientific definitions, numerical thresholds, seeds, software versions, public checkpoint references and reported results are retained. Hashes within protocols identify the original records; the package-root manifest verifies these exported copies. Technical hypothesis labels are defined in the protocols. The literal `exp3` in a random-seed hash formula is retained because changing it would change the generated controls.

The 43 processed CSV/JSON summary files are unchanged. Administrative decision/launch records and raw private provenance are excluded. This export does not contain model weights, token/boundary Parquet files or the focal acquisition implementation. Figure code and local plotting inputs are supplied under `../../source/`. No experiment or statistical resampling was run to prepare this export; optional consistency checks and plotting were executed in a disposable copy.
