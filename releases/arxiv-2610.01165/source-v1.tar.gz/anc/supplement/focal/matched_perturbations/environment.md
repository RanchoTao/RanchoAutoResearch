# The representation-aware matched-perturbation study environment and configuration snapshot

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Every calibration and acquisition cell has a machine-readable `environment.json`
beside its raw records. The two validated stacks used for full acquisition were:

| Panel | Python | PyTorch | CUDA | Transformers | Attention | GPU |
|---|---|---|---|---|---|---|
| Pythia-160M | 3.12.4 | 2.11.0+cu128 | 12.8 | 4.56.2 | SDPA | NVIDIA L40 |
| OLMo-2 7B | 3.12.4 | 2.6.0+cu124 | 12.4 | 4.51.3 | eager | NVIDIA L40 |

For both stacks: model state and intervention execution dtype were FP16 as
prespecified; intervention and metric calculations were FP32; batch size was 2;
autocast was off; deterministic algorithms were enabled; CUDA matmul TF32 and
cuDNN TF32 were disabled.

The acquisition script SHA-256 recorded by both stacks was
`ce8bfeebc2d10c6b2e47886bdeb042838a043ac3277ae7526312fd30ca11434d`.
Every environment record contains preregistration SHA-256
`92659883fc7a0855f49ff486923b1839929287939f90761622d1bd989798bbf9`.

Exact cells, commits, tolerances, seeds, bootstrap counts, and pilot selections
are in the prespecified protocol; administrative execution commands are not included in this summary export.
