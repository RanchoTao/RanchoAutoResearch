# Protocol changelog from the earlier matching pilot

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


The earlier matching pilot and representation-only diagnostic records are retained separately.

| Area | the earlier matching pilot | the representation-aware matched-perturbation study |
|---|---|---|
| Acquisition coefficient | Representation-only search around analytic ratio | Direct analytic `beta_star=r_target/r_natural` |
| Intervention quantities | Target and achieved norm retained | Ideal state/norm, target, actual post-cast state/norm explicitly distinct |
| Matching criterion | Record relative criterion plus universal 2% maximum | Exact representation-derived rounding bound; zero unexplained residual |
| Precision sentinel | Target, achieved, aggregate ULP bound | Full ideal/scale/addition/post-cast sentinel and element-change counts |
| Scientific conditioning | Requested common target with achieved norm recorded | Primary adjustment and plots condition on measured `r_exec` |
| Transfer denominator | Achieved local scale | Explicit measured `r_exec` |
| Search | Primary matching method | Prohibited in acquisition; QC diagnostic only |
| Near-zero handling | prespecified natural-scale exclusion plus relative error | Same prespecified exclusion; matching has no percentage denominator |

Scientific cells, windows, blocks, fixed beta grid, common-support targets,
output endpoints, propagation boundaries, replication hierarchy, held-out split,
and hypothesis decision structure are unchanged except where actual-`r_exec`
conditioning is required by the representation-aware protocol.
