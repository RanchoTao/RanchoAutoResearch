# The representation-aware matched-perturbation study pilot QC

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Overall: **PASS**

Pilot outputs were used only for implementation, endpoint-reproduction, and representation-aware numerical QC. No scientific checkpoint contrast was calculated or inspected.

| Cell | beta | Valid | Passed | Representation-bound exceptions | Max ideal error | Max observed error | Max unexplained residual | criterion |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| pythia_seed1_step14000 | 0.25 | 2304 | 2304 | 2264 | 1.4901161e-08 | 0.00028719008 | 0 | PASS |
| pythia_seed1_step14000 | 0.50 | 2304 | 2304 | 2262 | 2.9802322e-08 | 0.00022544991 | 0 | PASS |
| pythia_seed1_step14000 | 0.75 | 2304 | 2304 | 2257 | 8.9406967e-08 | 0.00028586388 | 0 | PASS |
| pythia_seed1_step14000 | 1.00 | 2304 | 2304 | 10 | 5.9604645e-08 | 2.7686357e-05 | 0 | PASS |
| pythia_seed1_step143000 | 0.25 | 2304 | 2304 | 2267 | 4.4703484e-08 | 0.00034059584 | 0 | PASS |
| pythia_seed1_step143000 | 0.50 | 2304 | 2304 | 2266 | 5.9604645e-08 | 0.00037001073 | 0 | PASS |
| pythia_seed1_step143000 | 0.75 | 2304 | 2304 | 2259 | 8.9406967e-08 | 0.00038215518 | 0 | PASS |
| pythia_seed1_step143000 | 1.00 | 2304 | 2304 | 2247 | 1.1920929e-07 | 0.00042426586 | 0 | PASS |
| olmo7b_stage1_step93000_tokens391B | 0.25 | 2304 | 2304 | 2211 | 5.9604645e-08 | 0.00019500405 | 0 | PASS |
| olmo7b_stage1_step93000_tokens391B | 0.50 | 2304 | 2304 | 2193 | 5.9604645e-08 | 0.00019729137 | 0 | PASS |
| olmo7b_stage1_step93000_tokens391B | 0.75 | 2304 | 2304 | 2190 | 1.1920929e-07 | 0.00015181303 | 0 | PASS |
| olmo7b_stage1_step93000_tokens391B | 1.00 | 2304 | 2304 | 934 | 1.1920929e-07 | 8.46982e-05 | 0 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 0.25 | 2304 | 2304 | 2236 | 2.2351742e-08 | 0.00021541864 | 0 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 0.50 | 2304 | 2304 | 2210 | 4.4703484e-08 | 0.00026662648 | 0 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 0.75 | 2304 | 2304 | 2205 | 1.7881393e-07 | 0.00018745661 | 0 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 1.00 | 2304 | 2304 | 1255 | 8.9406967e-08 | 0.00013008714 | 0 | PASS |

Failures: none.
