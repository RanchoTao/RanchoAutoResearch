# Preregistration: the representation-aware matched-perturbation study representation-aware norm-matched decomposition

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Specified before any the representation-aware matched-perturbation study model output is generated or inspected.

## 1. Scope and predecessor status

The continuous-output study is prespecified and read-only. The earlier matching pilot remains archived with a
technical `technical matching failure`. the representation-only diagnostic remains archived with forensic
classification `C. REPRESENTATION / QUANTIZATION LIMIT`. Neither predecessor's
scientific output columns have been inspected or used. The representation-aware matched-perturbation study is a
fresh scientific experiment.

representation-aware matching tests H1 (natural local magnitude), H2 (suffix transfer at matched actual
magnitude), H3 (both), and H9 (scalar decomposition insufficiency). H4/H5 are
not directly identified. 

## 2. Exact cells and prespecified data

- Pythia-160M runs 1, 4, 6, 7, 8, 9 at `step14000` and `step143000`;
- OLMo-2 7B at `stage1-step93000-tokens391B`, commit
  `ebee110f42239c33f87b113880d5acd077e45016`, and
  `stage1-step928646-tokens3896B`, commit
  `c0371f4281bf2376207646c6b62ddc6c442c7577`.

Pythia source/manifest SHA-256 values are
`ef75b67a0f3a316b6d465295e2dd58314738fd0e38bcf01790dba7022c35468e`
and `39055c86edd2a23b1a014e20695237d5cba3b0db90faf5a494ad32577fe374c1`.
OLMo manifest SHA-256 is
`96b0d8ad62c378e32bfdbc364e43bcea3bd7b26c0de332f9fe4a35219cd68f4d`.

Each cell uses all 18 prespecified windows: seeds 11, 23, 37; sequence indices 0--5;
257 IDs per window. Inputs are positions 0--255 and targets positions 1--256.
No padding, inserted BOS, or mask variation is allowed.

Pythia uses `PyTorch 2.11.0 / CUDA 12.8 / Transformers 4.56.2 / L40 / FP16 / batch 2` with SDPA.
OLMo uses `PyTorch 2.6.0 / CUDA 12.4 / Transformers 4.51.3 / L40 / FP16 / batch 2` with eager
attention. Both use FP16 model states, FP32 intervention/metric calculations,
batch size 2, `use_cache=False`, deterministic algorithms, and TF32 disabled.

## 3. Blocks and endpoint intervention

Pythia evaluates zero-based blocks 1--10; OLMo evaluates blocks 1--30. At a
block boundary, `h` is input residual, `h_plus` the intact block output, and
`delta0=h-h_plus`. For scalar beta,

```
h_ideal = float32(h_plus) + float32(beta)*
          (float32(h)-float32(h_plus))
h_exec  = cast_FP16(h_ideal).
```

At beta 0, an explicit conditional returns the original `h_plus` object. At beta 1,
an explicit conditional returns the original `h` tensor. These exact conditionals, not
the affine/cast expression, define endpoint behavior. Beta 0 must reproduce
intact logits exactly. Beta 1 must reproduce canonical identity bypass and the
direct identity endpoint within `1e-5` logits.

## 4. Ideal, requested, and actual local scales

For a hidden vector `x` with dimension `d`,
`RMS(x)=sqrt(mean_j x_j^2)` in FP32 over hidden dimension only. Define:

```
r_natural = RMS(float32(h)-float32(h_plus)) /
            (RMS(float32(h_plus))+1e-8)
r_target  = requested analytic shared norm
r_ideal   = RMS(h_ideal-float32(h_plus)) /
            (RMS(float32(h_plus))+1e-8)
r_exec    = RMS(float32(h_exec)-float32(h_plus)) /
            (RMS(float32(h_plus))+1e-8).
```

`r_target` is the requested norm; `r_exec` is the actual scientific conditioning
variable. They are never conflated. Relative L2, absolute RMS/L2, and cosine are
secondary representation diagnostics.

Records with `RMS(h_plus)<1e-6` are retained but excluded from primary matching,
gain, and prediction. Records whose paired natural scale is below `1e-4` are
retained and symmetrically excluded from primary matched/gain analyses. No new
minimum is chosen from the representation-only diagnostic.

## 5. Natural, graded, and common-support conditions

All cells evaluate fixed beta `0, .25, .5, .75, 1`. Beta 1 is natural bypass.

Natural beta-1 local scales are calibrated for paired checkpoints using only
representations. For each paired run/window/token/block:

```
r_common = min(r_natural_early,r_natural_final)
r_target(gamma) = gamma*r_common
gamma in {.25,.50,.75,1.00}
beta_star_checkpoint = r_target/r_natural_checkpoint.
```

`beta_star` is direct analytic scaling, clipped only for excursions within
`[-1e-6,1+1e-6]`; larger excursions fail. No interpolation or search is used
for acquisition. Targets cannot use output quantities.

## 6. Representation-aware admissibility and sentinel

For every matched record, calculate the actual unrounded FP32 `h_ideal`, its
FP16 `h_exec`, and

```
ideal_error = abs(r_ideal-r_target)
rounding_bound = RMS(float32(h_exec)-h_ideal) /
                 (RMS(float32(h_plus))+1e-8)
observed_error = abs(r_exec-r_target)
unexplained_raw = observed_error-(ideal_error+rounding_bound).
```

The reverse triangle inequality makes `rounding_bound` a conservative
representation-derived bound on the change in perturbation RMS caused by the
actual state cast. A record passes iff:

1. target is in ideal interval `[0,r_natural]`;
2. beta_star is valid and the prespecified arithmetic/cast path is used;
3. `ideal_error <= max(1e-7,1e-5*abs(r_target))`;
4. `unexplained_raw <= 5e-7`;
5. all quantities are finite.

The `5e-7` slack is fixed for FP32 accumulation/comparison, not learned from
matching outcomes. There is no relative-percentage matching criterion.

A `representation_bound_exception` is a passing record with
`observed_error > ideal_error+5e-7`; it records a material cast contribution but
is not a failure when explained by `rounding_bound`. An unexplained failure is
any record violating conditions 1--5.

For every pilot record and every matched record in expansion, retain:
`r_natural`, `beta_star`, `r_target`, `r_ideal`, post-scale perturbation norm,
`r_exec`, ideal/observed error, rounding bound, unexplained raw/residual,
FP16 ULP aggregate bound, count/fraction scaled-update elements rounded to zero,
count/fraction injected elements unchanged, and fraction state elements changed.
The central matching criterion is zero unexplained failures. Any failure stops.

## 7. Pointwise feasibility and pairing

Every target is checked against its own `[0,r_natural]` interval. Targets that
are genuinely infeasible in real arithmetic are retained, flagged, and
symmetrically excluded only by this prespecified rule. Each included early/final
record shares the same `r_target`; both actual `r_exec` values and bounds are
retained. Every prespecified run/window/block/gamma stratum must retain at least one
feasible record at both checkpoints or coverage fails.

## 8. Output and propagation measurements

Primary output endpoint is Jensen--Shannon divergence. Confirmatory endpoints
are forward `KL(p_intact||p_intervention)`, target-token NLL change, and intact
top1-vs-intact-runner-up logit-margin loss. Top-1 disagreement is secondary.
Definitions and probability criteria are inherited from the continuous-output study.

For natural beta 1 and each matched gamma, retain per-token differences after
the intervention block, every downstream transformer block, and final norm:
relative RMS/L2, absolute RMS/L2, cosine, change from prior boundary, boundary
index/type, remaining depth, and suffix progress. Actual `r_exec` is the origin.

Primary operational transfer is
`suffix_gain_JS=JS/(r_exec^2+1e-12)`, undefined for `r_exec<1e-4`.
Confirmatory gains use KL and positive logit-margin loss. The representation-
only suffix predictor is
`t_repr=log((r_final_norm+1e-12)/(r_exec+1e-12))`.

## 9. Pilot

Pilot cells are both checkpoints of Pythia run 1 and both OLMo checkpoints.
Pilot blocks are Pythia 1, 5, 10 and OLMo 1, 15, 30. Pilot windows are sequence
0 from seeds 11, 23, 37, executed with their original sequence-1 companions;
companion rows are not retained.

Until every pilot criterion passes, no directional scientific summary is calculated
or inspected. criteria are exact semantic hashes/counts; deterministic repeats;
beta-0 and beta-1 endpoints; correct beta_star and ideal interval; finite actual
norm/sentinel; zero unexplained matching failures; finite scientific metric
calculation without directional inspection; probability normalization `<=1e-5`;
divergence negativity `>=-1e-6`; identical-distribution divergence `<=1e-6`;
and exact output/propagation row coverage. Failure stops without Protocol V3.

## 10. Primary matched-actual-norm analysis

Matched scientific analysis uses only records passing Section 6 and conditions
on measured `r_exec`. The primary Pythia estimate is computed separately per
run using matched gamma records. Fit OLS on raw JS with predictors:

```
checkpoint + z + z^2 + normalized_depth + normalized_depth^2 + gamma indicators
+ checkpoint*z + checkpoint*z^2
```

where `z=log(r_exec+1e-12)` standardized within run using the pooled early/final
matched records. Marginally standardize by predicting each retained record's
covariates twice, once as early and once as final, and average `prediction_final
- prediction_early`. This is a noncausal adjustment for residual representable-
norm differences. Report the unadjusted paired-target contrast secondarily.

The six run-level adjusted contrasts are replication units and are resampled
with replacement for 100,000 percentile-bootstrap draws, seed `20260922`.
OLMo uses the same standardization once, descriptively; a 10,000-window
bootstrap with seed `20260923` describes stability but not training replication.

A checkpoint effect is material if its Pythia 95% interval excludes zero and
its absolute change is at least 5% of the mean absolute adjusted early/final JS
level. Natural local scale, natural JS, matched adjusted JS, and matched suffix
gain are primary decomposition quantities.

## 11. Propagation localization

Zones are intervention (`immediate`), transformer progress `(0,1/3]` (`early`),
`(1/3,2/3]` (`middle`), `(2/3,1]` (`late`), then `final_norm`. For matched
conditions, report the earliest zone with a material paired-run separation.
Display blocks remain Pythia 1, 5, 10 and OLMo 1, 15, 30.

## 12. Held-out decomposition

Sequence indices 2 and 5 from each seed are test windows; 0, 1, 3, 4 are train.
The split is shared across checkpoints/runs/blocks/conditions. Fit separately by
family on natural beta 1 plus matched gamma conditions. Response is
`log(JS+1e-12)`; continuous predictors are standardized from training only.

- nuisance `N`: normalized depth and squared depth; Pythia run indicators;
- `M1`: `N + log(r_exec+1e-12)`;
- `M2`: `N + t_repr`;
- `M3`: `N + log(r_exec+1e-12) + t_repr`;
- `M4`: `M3 + checkpoint + checkpoint*log(r_exec+1e-12)
  + checkpoint*t_repr`.

Report test R-squared and MAE. Magnitude increment is `M3-M2`; suffix increment
is `M3-M1`. Pythia increment is material if six-run bootstrap CI is above zero
and mean is at least .01. Residual checkpoint structure is material if
`M4-M3>=.02` with CI above zero. M3 is inadequate at R-squared below .20.

## 13. Aggregation, robustness, and cross-family status

Tokens are never training replications. Primary natural summaries average
tokens within window/block, then windows/layers within run/checkpoint. OLMo is
one descriptive trajectory.

Robustness checks, without replacing primary decisions: relative L2; KL and
logit-margin endpoints/gains; gain epsilons `1e-10` and `1e-14`; thresholds
`1e-3` and none; depth thirds; removal of one-binary16-spacing top-two cases;
Pythia leave-one-run-out; results by gamma; and unadjusted requested-target
contrasts. Compare family signs for natural magnitude, matched adjusted JS,
suffix gain, and propagation without forcing universality.

## 14. Prespecified interpretation rule

Technical endpoint, representation, coverage, or finite-metric failure gives
**technical matching failure**. Otherwise apply in priority order:

1. **scalar-model inadequacy criterion**: matched adjusted JS material, M3 inadequate, and M4 residual
   checkpoint structure material.
2. **joint local/downstream criterion**: natural local scale and matched adjusted JS material, with both
   magnitude and suffix predictive increments material.
3. **suffix-only criterion**: matched adjusted JS and matched suffix gain material, suffix
   increment material, magnitude increment not material, and M3 adequate.
4. **local-magnitude-only criterion**: natural local scale material; matched adjusted JS nonmaterial and
   its absolute change no more than 25% of natural-JS change; magnitude increment
   material; suffix increment not material.
5. **inconclusive pattern**: every other technically valid pattern.

Direction controls were planned only after technically valid matching if either scalar-model inadequacy was supported or matched adjusted JS and residual checkpoint structure were both material. 

## 15. Changes from the earlier matching pilot

The scientific cells, windows, blocks, fixed grid, common-support targets,
endpoints, propagation, split, uncertainty, and hypothesis decision structure
are retained. Required matching changes are:

1. direct analytic beta replaces acquisition search;
2. ideal state, requested target, and post-cast actual state/norm are distinct;
3. representation-derived FP16 rounding bound replaces the universal relative
   cap;
4. zero unexplained residual is the hard criterion;
5. the full representation sentinel is retained;
6. primary matched JS is adjusted/standardized on actual measured `r_exec`;
7. suffix gain and predictors use `r_exec`.

No clause or threshold is inherited silently from the representation-aware matching proposal.

## 16. Artifacts and missing data

No silent checkpoint, window, token, block, gamma, condition, or boundary
substitution is allowed. Failures are preserved and not imputed. A cell is
complete only with exact hashes/counts and an atomic completion record.
the representation-aware matched-perturbation study stores preregistration/hash, changelog, config, code/tests,
commands/environments, pilot QC, representation QC, losslessly sufficient
per-token outputs and propagation, processed tables, analysis, figures, results,
decision, and manifest. The interpretation distinguishes measurements from hypotheses.
