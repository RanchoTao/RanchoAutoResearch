# The representation-aware matched-perturbation study representation-aware matching QC

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


## Results

The preregistered pilot passed all four cells and every beta stratum. The full
acquisition then retained 3,317,760 matched token-by-block records:

| Panel | Valid matched records | Passed | Representation-bound exceptions | Pointwise infeasible |
|---|---:|---:|---:|---:|
| Pythia-160M | 2,211,840 | 2,211,840 | 1,896,795 | 0 |
| OLMo-2 7B | 1,105,920 | 1,105,920 | 900,567 | 0 |
| Total | 3,317,760 | 3,317,760 | 2,797,362 | 0 |

- Unexplained matching failures: **0**.
- Maximum positive unexplained residual: `1.0112671589e-08`, below the prespecified
  `5e-7` slack.
- Maximum ideal target error: `2.3841857910e-07`, within the prespecified
  target-dependent ideal tolerance.
- Maximum observed post-cast target error: `6.0093402863e-04`.
- Representation-bound exceptions: 2,797,362 (84.315% of valid records). These
  are passing records whose material cast contribution is explained by the
  recorded representation-derived rounding bound.
- Canonical beta-1 mismatches: 0 in every cell.
- Beta-0 intact mismatches: 0 in every cell.
- Pointwise-infeasible records: 0.
- Maximum beta-1 direct-identity logit difference: 0.
- Maximum deterministic-repeat logit difference: 0.
- Maximum probability-normalization residual: `1.4305114746e-06`, below
  `1e-5`.
- Minimum raw computed divergence: `-2.1493438851e-07`, within the prespecified
  `-1e-6` floating-point tolerance.
- Exact full coverage: 7,464,960 condition rows and 44,928,000 propagation
  rows across 14 cells.

The large exception fraction is not a failure: the representation-aware matched-perturbation study was designed to
measure the actual post-addition FP16 state and admit its observed norm only
when the full discrepancy is bounded by the recorded FP16 representation
error. The scientific conditioning variable is measured `r_exec`.

## Interpretation

The prior the earlier matching pilot failure was procedural: a universal relative-error cap
rejected representable states even when their mismatch was fully explained by
FP16 residual representation. The representation-aware matching bound resolves that issue without using
any scientific output metric.

## Unresolved interpretations

No claim about model behavior follows from the frequency of representation-
bound exceptions itself. It is a numerical property of this execution path,
not evidence for a training mechanism.
