# The representation-aware matched-perturbation study results: representation-aware norm-matched local perturbation / suffix-transfer decomposition

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


## Scope and technical status

The representation-aware matched-perturbation study used the prespecified 18-window panels, all six Pythia-160M runs at
steps 14k and 143k, and the exact two OLMo-2 7B checkpoints. It evaluated
Pythia blocks 1--10 and OLMo blocks 1--30. The pilot and all 14 full cells
passed. No checkpoint, window, block, token, or intervention was substituted.

The raw acquisition contains 7,464,960 token-by-block condition records and
44,928,000 token-by-block-by-boundary propagation records. Of these, 3,317,760
are valid matched-condition records. All passed the representation-aware criterion;
there were zero unexplained matching failures. Full numerical details are in
`matching_validation.md`.

## Results

### Natural interventions

For Pythia, run-level hierarchical means showed:

| Quantity | Early | Final | Final - early | 95% run bootstrap CI | Relative change |
|---|---:|---:|---:|---:|---:|
| Natural local relative RMS | 0.394577 | 0.592729 | +0.198152 | [0.182732, 0.213997] | +50.22% |
| Natural final JS | 0.072269 | 0.121588 | +0.049319 | [0.043509, 0.053710] | +68.24% |

Both changes were positive in all six runs. Natural KL, target-token NLL
change, logit-margin loss, and top-1 flip probability also increased. Runs,
not tokens, are the replication units.

For the single OLMo trajectory, natural local relative RMS was nearly unchanged
(0.392470 to 0.391495; -0.25%), while natural JS decreased from 0.023287 to
0.017989 (-22.75%). The 18-window descriptive interval for the local-scale
change crossed zero; the descriptive interval for natural-JS change did not.
This is not independent-seed replication.

### Matched actual local norm

The preregistered Pythia OLS adjustment conditioned on measured `r_exec`,
depth, gamma, and prespecified interactions. Marginally standardized JS decreased
from 0.029032 to 0.026409:

`delta = -0.002623`, 95% six-run bootstrap CI
`[-0.004780, -0.000996]`, a -9.03% change.

Five of six run-level contrasts were negative; run 4 was slightly positive
(`+0.000199`). Unadjusted paired-target JS gave the same aggregate result to
the displayed precision. Matched KL and target-token NLL change also decreased;
the logit-margin-loss interval crossed zero.

The Pythia matched-JS contrast varied with gamma: gamma 0.25 increased
(`+0.001291`, CI `[0.000866, 0.001784]`), gamma 0.50 was unresolved, and gamma
0.75 and 1.00 decreased (`-0.003289` and `-0.008606`, respectively, with CIs
excluding zero). Thus the pooled matched effect is not scale-invariant.

For OLMo, adjusted matched JS decreased from 0.0064244 to 0.0061996
(`-0.00022484`, -3.50%). The adjusted 18-window descriptive interval was
`[-0.00023059, -0.00021978]`; the unadjusted window interval crossed zero.
Matched KL, NLL change, and logit-margin loss decreased descriptively. OLMo
remains one released trajectory.

### Operational suffix transfer and propagation

Pythia's operational `JS/(r_exec^2+eps)` summary increased from 0.49735 to
0.98141 (`+0.48406`, CI `[0.34298, 0.58071]`). This sign was robust to the
predeclared epsilon, threshold, FP16-boundary, gamma, and depth checks.
However, the direct matched-JS endpoint decreased overall and changed sign
across gamma. The ratio and endpoint therefore describe different weighting of
a heterogeneous, nonlinear response and must not be collapsed into a single
"amplification" claim.

At the matched intervention boundary, Pythia relative RMS was equal by design
(`delta = -1.5e-08`). The early and middle suffix zones had small negative
contrasts that did not clear the preregistered 5% materiality threshold. The
earliest material separation was the late zone (`delta = -0.04419`, CI
`[-0.05211, -0.03612]`), followed by final normalization (`delta = -0.15967`,
CI `[-0.17391, -0.14418]`).

OLMo also began at equal matched local scale. Its descriptive propagation
contrast was most negative in the early and middle zones (`-0.00894` and
`-0.01002`) and was smaller at the late zone and final normalization
(`-0.00055` and `-0.00278`). No replication claim is made.

### Held-out decomposition

Sequence indices 2 and 5 were held out exactly as preregistered.

| Panel | M1 magnitude R2 | M2 suffix-feature R2 | M3 combined R2 | M4 + checkpoint R2 |
|---|---:|---:|---:|---:|
| Pythia | 0.5139 | 0.0152 | 0.5426 | 0.6234 |
| OLMo, descriptive | 0.3941 | 0.0737 | 0.4566 | 0.4563 |

For Pythia, the magnitude increment `M3-M2` was 0.52723, CI
`[0.50991, 0.54511]`; the suffix-feature increment `M3-M1` was 0.02836, CI
`[0.01653, 0.04069]`. Both met the prespecified materiality rule. M3 exceeded the
0.20 adequacy threshold. Adding checkpoint structure produced a further
0.08113, CI `[0.06518, 0.09303]`, which also met its materiality rule.

For OLMo, descriptive increments were 0.38294 for magnitude, 0.06250 for the
suffix feature, and -0.00027 for checkpoint structure.

## Interpretation

The Pythia longitudinal increase under natural bypass is consistent with a
joint decomposition, not a single scalar cause. The natural omitted update has
a substantially larger measured local norm at the final checkpoint, while a
same-sized representable perturbation produces a modestly smaller pooled final
JS and separates mainly late in the remaining computation. The two components
therefore change in opposing directions in this panel.

The OLMo counterexample is consistent with a different balance: mean natural
local magnitude is nearly stable, whereas natural and matched continuous
output responses both decrease. The data do not support a universal temporal
direction or a universal component balance across model families.

Because the combined scalar model is adequate but checkpoint terms still add
substantial held-out predictive value in Pythia, scalar local magnitude and the
single scalar propagation feature are informative but incomplete. This narrows
the mechanism space without identifying a mechanism.

## Unresolved interpretations

The residual checkpoint structure could reflect perturbation direction,
checkpoint-specific representation geometry, nonlinear suffix dynamics, or
another omitted structural variable. The representation-aware matched-perturbation study does not distinguish
these possibilities. A direction-controlled experiment is needed before any
direction-specific account can be accepted.

## Fixed classification

The preregistered priority rule assigns **joint local/downstream criterion**: natural local magnitude and
matched suffix transfer both change, and both magnitude and suffix features
make material held-out contributions. scalar-model inadequacy criterion is not assigned because M3 is not
inadequate, although its residual-checkpoint criterion is positive.

