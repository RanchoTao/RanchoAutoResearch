# Preregistration: the direction-control study natural direction versus matched-control propagation

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Specified before any the direction-control study model output is generated or inspected.

## 1. Scope and hypotheses

The continuous-output study and the representation-aware matched-perturbation study are prespecified and read-only. The representation-aware matched-perturbation study's
classification is `joint local/downstream criterion`: natural local perturbation magnitude and matched
suffix transfer both changed, with material residual checkpoint structure.
the direction-control study discriminates:

- **H4, generic suffix contractivity:** natural and control directions have
  similar propagation after initial magnitude and readout alignment are
  controlled;
- **H5, natural-direction specificity:** the natural missing-update direction
  is preferentially attenuated relative to every control family after those
  controls;
- **H9, direction/readout geometry:** apparent natural/control differences are
  explained by initial output-sensitive alignment rather than natural identity.

H3 remains the prespecified the matched-perturbation study decomposition result unless the natural
condition fails its replay criterion. 

## 2. Exact cells, semantic inputs, and stacks

Use all 18 prespecified windows (evaluation seeds 11, 23, 37; sequence indices 0--5;
257 IDs each) and the same input/target convention as the continuous-output and matched-perturbation studies.

- Pythia-160M runs 1, 4, 6, 7, 8, 9 at `step14000` and `step143000`;
- OLMo-2 7B at `stage1-step93000-tokens391B`, commit
  `ebee110f42239c33f87b113880d5acd077e45016`, and
  `stage1-step928646-tokens3896B`, commit
  `c0371f4281bf2376207646c6b62ddc6c442c7577`.

Semantic hashes are inherited exactly: Pythia text
`ef75b67a0f3a316b6d465295e2dd58314738fd0e38bcf01790dba7022c35468e`,
Pythia manifest
`39055c86edd2a23b1a014e20695237d5cba3b0db90faf5a494ad32577fe374c1`,
and OLMo manifest
`96b0d8ad62c378e32bfdbc364e43bcea3bd7b26c0de332f9fe4a35219cd68f4d`.

Pythia uses PyTorch 2.11.0/CUDA 12.8/Transformers 4.56.2 with SDPA. OLMo
uses PyTorch 2.6.0/CUDA 12.4/Transformers 4.51.3 with eager attention. Both use
FP16 model states, FP32 intervention/metric arithmetic, batch size 2,
`use_cache=False`, deterministic algorithms, and TF32 disabled.

## 3. prespecified layers and pilot

To bound cost while spanning suffix length, Pythia uses zero-based blocks
`[1,5,10]`; OLMo uses `[1,15,30]`. These are the already validated
shallow/middle/deep the representation-aware matched-perturbation study pilot blocks. No fourth layer is added: the
full boundary trajectory from the shallow and middle interventions already
contains the late-suffix region implicated by the representation-aware matched-perturbation study.

Pilot cells are both checkpoints of Pythia run 1 and both OLMo checkpoints.
Pilot windows are sequence 0 from each evaluation seed, executed with their
original sequence-1 batch companions; companions are not retained. Until every
pilot QC criterion passes, no the direction-control study directional scientific contrast is
calculated or inspected.

## 4. Natural intervention

At block `l`, let `h` be block input, `h_plus` intact block output,
`u=h_plus-h`, and `delta_nat=h-h_plus=-u`. The natural intervention returns the
original FP16 `h` object exactly. Its measured execution perturbation is

`d_nat_exec=float32(h)-float32(h_plus)`.

Primary initial magnitude is

`r_initial=RMS(d_exec)/(RMS(float32(h_plus))+1e-8)`.

The natural condition must reproduce the representation-aware matched-perturbation study beta-1 on the pilot subset:
top-1 IDs exactly and JS, KL, NLL change, logit-margin loss, and `r_initial`
within absolute `1e-6`.

## 5. prespecified control families

### C1 random orthogonal

Use four controls with public seeds `[3101,3102,3103,3104]`. For every
pair/window/block, generate an FP32 standard-normal vector using a stable
SHA-256-derived 63-bit seed of
`exp3|seed|pair_id|evaluation_seed|sequence_index|block`. The pair ID excludes
checkpoint, so paired checkpoints receive the same base random realization.

For each token, Euclidean-project the random vector out of `d_nat_exec`:

`v_perp=v-(dot(v,d_nat)/dot(d_nat,d_nat))*d_nat`.

The FP32 ideal direction must have absolute cosine with `d_nat_exec <=1e-5`.
After scaling, residual addition, and FP16 representation, executed absolute
cosine must be `<=0.01`. Any violation stops the experiment; tolerances are not
relaxed.

### C2 token-permuted natural

Within each 256-token window and block, token position `p` uses the natural
direction from `(p+137) mod 256` in the same checkpoint/window. The offset 137
is prespecified, nonzero, and coprime to 256. It is applied independently within each
window, including when two windows share an execution batch.

### C3 adjacent block

Not run. Moving an update measured at another residual state to the present
boundary introduces a base-state semantic ambiguity. Its optional status cannot
block the primary random-orthogonal and token-permuted assay.

## 6. Representation-aware norm matching

For every control, scale its FP32 direction so its ideal absolute RMS equals
the measured natural execution perturbation RMS for the same token/block:

`s=RMS(d_nat_exec)/(RMS(v)+1e-30)` and
`h_ctrl_ideal=float32(h_plus)+s*v`.

The executed state is `cast_FP16(h_ctrl_ideal)`. The natural measured
`r_initial` is the requested target; the control's actual post-cast `r_initial`
is the scientific variable. Retain ideal achieved norm, actual achieved norm,
absolute/relative target error, element change/zero counts, FP16 ULP aggregate,
and

`rounding_bound=RMS(float32(h_ctrl_exec)-h_ctrl_ideal)/(RMS(h_plus)+1e-8)`.

A record passes iff target/direction quantities are finite, the ideal target
error is at most `max(1e-7,1e-5*abs(target))`, and

`observed_error-(ideal_error+rounding_bound) <=5e-7`.

There is no universal percentage error cap. Natural magnitudes below `1e-4`
or base RMS below `1e-6` are retained but excluded symmetrically from primary
specificity, adjustment, and prediction.

## 7. Readout-sensitive reference and alignment

The primary output-sensitive reference is the intact top-token versus intact
runner-up unembedding contrast at each token:

`w = W_unembed[top1]-W_unembed[runnerup]`.

The residual-stream and unembedding dimensions coincide in both prespecified model
families. For each executed perturbation `d`, retain:

- signed and absolute cosine alignment with `w`;
- signed and absolute relative projection
  `p=dot(d,w/||w||)/(sqrt(hidden_dim)*(RMS(h_plus)+1e-8))`.

Primary geometry adjustment uses `abs(p)`. Exact simultaneous construction of
random directions that are both orthogonal to the natural direction and equal
in readout projection is not guaranteed feasible. Therefore dual matching is
not attempted; the outcome-independent common-support adjustment below is
primary and prespecified before outcomes.

Within each run/checkpoint/layer, define readout common support as the
intersection of the family-specific 1st--99th percentile intervals of
`abs(p)` for natural, random-orthogonal, and token-permuted records. Retain
records inside the intersection. Each family must retain at least 10% of its
eligible records and at least 256 records in every stratum (77 records for the
three-window pilot); otherwise the readout-control criterion fails.

## 8. Propagation and output measurements

At the injection boundary, every downstream transformer output, the last
transformer output immediately before final normalization, and the output of
final normalization, retain:

- relative RMS and relative L2 difference from intact;
- cosine between perturbed and intact residual;
- cosine between current and initial perturbation vectors;
- log boundary-to-boundary gain and change in relative RMS;
- boundary index/type, suffix progress, and remaining transformer depth.

Final normalization is an explicit boundary and is never averaged with the
last transformer boundary.

Output records retain JS divergence (primary), forward KL, target-token NLL
change, logit-margin loss, and top-1 disagreement (secondary), using the prespecified
the continuous-output study definitions and FP32 extraction.

## 9. Primary attenuation and specificity statistics

For each direction record define

`A_hidden=log((r_post_final_norm+1e-12)/(r_initial+1e-12))`.

More negative values mean greater attenuation. Unadjusted token specificity is

`S_unadj=A_natural-0.5*(mean_seed(A_random)+A_permuted)`.

Thus negative specificity means greater natural-direction attenuation, zero
means no preferential attenuation, and positive means greater natural
preservation/amplification.

Primary readout-adjusted specificity is estimated separately for each
run/checkpoint/layer on common support by weighted least squares:

`A_hidden ~ family + x + x^2 + z + family:x`,

where `x=abs(readout projection)` and `z=log(r_initial+1e-12)` are standardized
within stratum. Random records receive weight 1/4 per seed; natural and
permuted records receive weight 1. Marginal standardization predicts every
retained covariate row as each family. Report natural-minus-random,
natural-minus-permuted, and their equal-family mean. Coefficients are not
causal.

Secondary output specificity replaces `A_hidden` with
`G_JS=log((JS+1e-12)/(r_initial^2+1e-12))` and uses the same adjustment.

## 10. Statistical hierarchy and checkpoint comparison

Pythia run-level, checkpoint-paired effects are the replication units. Layer
effects are averaged equally within run; random seeds never count as model
replications. Six runs are resampled with replacement for 100,000 percentile
bootstrap draws, seed `20260924`. A contrast is material when its 95% interval
excludes zero and its absolute magnitude is at least 0.05 log units.

Report adjusted specificity at early and final checkpoints and the paired
change `S_final-S_early`. OLMo is one descriptive trajectory; 10,000 window
bootstrap draws with seed `20260925` describe within-trajectory stability only.

## 11. Boundary localization

At every explicit boundary calculate the same adjusted natural-minus-control
attenuation using `A_b=log((r_b+1e-12)/(r_initial+1e-12))`. The localization
point is the earliest boundary where pooled Pythia equal-family specificity is
at most -0.05 with a run-bootstrap upper bound below zero and either the next
boundary also qualifies or the boundary is final normalization. Family-specific
H5 localization requires both natural-minus-random and
natural-minus-permuted to qualify. Final-normalization contribution is the
paired change in specificity from the last transformer output to the explicit
post-normalization boundary.

## 12. Held-out explanatory prediction

Sequence indices 2 and 5 are test windows; 0, 1, 3, 4 are train. The split is
shared across families, checkpoints, runs, layers, and control seeds. Response
is `log(JS+1e-12)`. Continuous variables are standardized from train only.
Prespecified nuisance terms are normalized depth and its square, checkpoint, and
Pythia run indicators.

- D1: nuisance + `log(r_initial+1e-12)`;
- D2: D1 + signed and absolute readout projection;
- D3: D1 + pre-final-normalization attenuation and final-normalization gain;
- D4: D3 + readout projections + natural and permuted family indicators.

Also fit the preregistered nested `D4-noID` (D4 without family indicators) to
isolate natural/direction-family incremental value after geometry and generic
propagation. Report test R-squared and MAE. Pythia run-level R-squared
increments use the same 100,000-run bootstrap. An increment is material when
CI is above zero and mean is at least .01.

## 13. QC and stopping criteria

Before expansion require:

1. semantic hashes, windows, counts, and selected layers exact;
2. deterministic repeated intervention logits within `1e-5` and identical
   decisions;
3. beta-0/intact exact equality for every pilot batch/layer and the first full
   batch/layer;
4. natural direct-identity equality and the representation-aware matched-perturbation study pilot replay;
5. random construction deterministic; ideal and executed orthogonality pass;
6. permutation offset/mapping exact and deterministic;
7. zero unexplained representation-aware norm-match failures;
8. readout vectors/projections finite and common-support coverage passes;
9. probabilities normalize within `1e-5`, divergences are no less than
   `-1e-6`, and identical distributions give KL/JS within `1e-6`;
10. hooks execute once, cache/attention outputs are disabled, restoration is
    exact, and output/propagation row coverage is exact.

Pilot failure stops the experiment. Criteria are not relaxed and no replacement
control is introduced.

## 14. Prespecified interpretation criteria

Technical or control failure precludes scientific interpretation. Otherwise apply the following criteria in priority order:

1. **targeted-compensation criterion** only if, at at least one checkpoint, adjusted
   natural-minus-random and natural-minus-permuted aggregate specificities are
   both negative material; each family contrast is negative in at least five
   of six runs and is negative with bootstrap upper below zero in at least two
   of three layers; both families meet the downstream localization criterion;
   and D4 identity/family terms add material held-out value over D4-noID.
2. **combined generic-propagation/readout account** if both the generic-propagation criterion and readout-geometry criterion patterns below hold.
3. **readout-geometry criterion** if unadjusted specificity is material at a checkpoint, both
   adjusted family contrasts there are nonmaterial (`abs(mean)<0.05` and CI
   includes zero), D2 improves materially over D1, and D4 adds less than .01
   over D4-noID or its CI includes zero.
4. **generic-propagation criterion** if both adjusted family contrasts are nonmaterial at both
   checkpoints and the family-average checkpoint change in `A_hidden` is
   material, same-signed, and CI-excluding-zero for natural, random, and
   permuted families.
5. **no single prespecified account established** for every other technically valid pattern.

If no criterion is met, no single account is established. Only the targeted-compensation criterion supports the phrase
"direction-specific downstream compensation". No class supports stronger
anthropomorphic language.

## 15. Robustness and hypothesis updates

Without replacing primary decisions, report signed versus absolute alignment,
cosine instead of relative projection, JS/KL/NLL/margin output specificity,
removal of one-binary16-spacing top-two cases, random seeds separately,
layers separately, leave-one-run-out Pythia results, and early/final conditions
separately.

At completion, assess whether H4, H5, H9, H3, and U1 are strengthened, weakened, not ruled out, ruled out, or untested. U1 denotes the prespecified cross-family
non-universality proposition defined in the pre-analysis plan; this assay can update it
only descriptively through OLMo.

## 16. Required artifacts and language

Store preregistration/hash, config, implementation/tests, commands,
environments, pilot and matching QC, losslessly sufficient condition,
propagation and readout records, processed tables, held-out results, four
figures, results, decision, and SHA-256 artifact manifest under
the retained acquisition archive (not included in this summary export).

The interpretation distinguishes measurements from hypotheses. Without meeting the targeted-compensation criterion, interpretation is limited to generic attenuation, contractivity, propagation, direction
sensitivity, readout alignment, and natural-direction specificity. 
