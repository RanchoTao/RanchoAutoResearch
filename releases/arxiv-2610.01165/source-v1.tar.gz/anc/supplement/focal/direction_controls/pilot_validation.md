# The direction-control study pilot QC

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Overall: **PASS**

Only semantic, endpoint, representation, orthogonality, replay, finite-metric, and readout-common-support quantities were inspected. No direction-specific attenuation or output contrast was calculated.

| Cell | Block | Family | Eligible | Support low | Support high | Retained | Fraction | criterion |
|---|---:|---|---:|---:|---:|---:|---:|---|
| pythia_seed1_step14000 | 1 | natural | 768 | 0.0003347303 | 0.04125579 | 745 | 0.9701 | PASS |
| pythia_seed1_step14000 | 1 | random_orthogonal | 3072 | 0.0003347303 | 0.04125579 | 2981 | 0.9704 | PASS |
| pythia_seed1_step14000 | 1 | token_permuted | 768 | 0.0003347303 | 0.04125579 | 752 | 0.9792 | PASS |
| pythia_seed1_step14000 | 5 | natural | 768 | 0.0001631187 | 0.04158821 | 675 | 0.8789 | PASS |
| pythia_seed1_step14000 | 5 | random_orthogonal | 3072 | 0.0001631187 | 0.04158821 | 3010 | 0.9798 | PASS |
| pythia_seed1_step14000 | 5 | token_permuted | 768 | 0.0001631187 | 0.04158821 | 747 | 0.9727 | PASS |
| pythia_seed1_step14000 | 10 | natural | 768 | 0.0001719758 | 0.03820743 | 686 | 0.8932 | PASS |
| pythia_seed1_step14000 | 10 | random_orthogonal | 3072 | 0.0001719758 | 0.03820743 | 3009 | 0.9795 | PASS |
| pythia_seed1_step14000 | 10 | token_permuted | 768 | 0.0001719758 | 0.03820743 | 744 | 0.9688 | PASS |
| pythia_seed1_step143000 | 1 | natural | 768 | 0.0003565913 | 0.0415794 | 737 | 0.9596 | PASS |
| pythia_seed1_step143000 | 1 | random_orthogonal | 3072 | 0.0003565913 | 0.0415794 | 2933 | 0.9548 | PASS |
| pythia_seed1_step143000 | 1 | token_permuted | 768 | 0.0003565913 | 0.0415794 | 742 | 0.9661 | PASS |
| pythia_seed1_step143000 | 5 | natural | 768 | 0.0002895089 | 0.05317819 | 728 | 0.9479 | PASS |
| pythia_seed1_step143000 | 5 | random_orthogonal | 3072 | 0.0002895089 | 0.05317819 | 2996 | 0.9753 | PASS |
| pythia_seed1_step143000 | 5 | token_permuted | 768 | 0.0002895089 | 0.05317819 | 747 | 0.9727 | PASS |
| pythia_seed1_step143000 | 10 | natural | 768 | 0.0004390206 | 0.06601241 | 741 | 0.9648 | PASS |
| pythia_seed1_step143000 | 10 | random_orthogonal | 3072 | 0.0004390206 | 0.06601241 | 2901 | 0.9443 | PASS |
| pythia_seed1_step143000 | 10 | token_permuted | 768 | 0.0004390206 | 0.06601241 | 747 | 0.9727 | PASS |
| olmo7b_stage1_step93000_tokens391B | 1 | natural | 768 | 0.0001366389 | 0.03195905 | 751 | 0.9779 | PASS |
| olmo7b_stage1_step93000_tokens391B | 1 | random_orthogonal | 3072 | 0.0001366389 | 0.03195905 | 2977 | 0.9691 | PASS |
| olmo7b_stage1_step93000_tokens391B | 1 | token_permuted | 768 | 0.0001366389 | 0.03195905 | 740 | 0.9635 | PASS |
| olmo7b_stage1_step93000_tokens391B | 15 | natural | 768 | 9.946321e-05 | 0.01631189 | 677 | 0.8815 | PASS |
| olmo7b_stage1_step93000_tokens391B | 15 | random_orthogonal | 3072 | 9.946321e-05 | 0.01631189 | 2986 | 0.9720 | PASS |
| olmo7b_stage1_step93000_tokens391B | 15 | token_permuted | 768 | 9.946321e-05 | 0.01631189 | 739 | 0.9622 | PASS |
| olmo7b_stage1_step93000_tokens391B | 30 | natural | 768 | 0.0001430512 | 0.01196234 | 549 | 0.7148 | PASS |
| olmo7b_stage1_step93000_tokens391B | 30 | random_orthogonal | 3072 | 0.0001430512 | 0.01196234 | 2964 | 0.9648 | PASS |
| olmo7b_stage1_step93000_tokens391B | 30 | token_permuted | 768 | 0.0001430512 | 0.01196234 | 607 | 0.7904 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 1 | natural | 768 | 0.0001746695 | 0.02572085 | 745 | 0.9701 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 1 | random_orthogonal | 3072 | 0.0001746695 | 0.02572085 | 2980 | 0.9701 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 1 | token_permuted | 768 | 0.0001746695 | 0.02572085 | 730 | 0.9505 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 15 | natural | 768 | 9.175874e-05 | 0.01557033 | 708 | 0.9219 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 15 | random_orthogonal | 3072 | 9.175874e-05 | 0.01557033 | 3006 | 0.9785 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 15 | token_permuted | 768 | 9.175874e-05 | 0.01557033 | 742 | 0.9661 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 30 | natural | 768 | 0.0001659554 | 0.01769214 | 530 | 0.6901 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 30 | random_orthogonal | 3072 | 0.0001659554 | 0.01769214 | 2985 | 0.9717 | PASS |
| olmo7b_stage1_step928646_tokens3896B | 30 | token_permuted | 768 | 0.0001659554 | 0.01769214 | 585 | 0.7617 | PASS |

Failures: none.
