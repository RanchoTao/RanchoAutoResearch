# The direction-control study: Natural direction versus matched-control propagation

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


Preregistration SHA-256:
`21096072a46b8490cbd9d7f61d4364e953865497c64e265238632fe3c92251c0`

Primary preregistered classification: **no single prespecified account established**.

The sign convention throughout is
`A_hidden = log(r_post-final-norm / r_initial)` and
`specificity = A_natural - A_control`. More negative values mean greater
attenuation of the natural direction than the named control.

## Results

### Completion and QC

All exact preregistered cells completed:

- Pythia-160M, Hella-derived panel: steps 14k and 143k for runs 1, 4, 6, 7,
  8, and 9; blocks 1, 5, and 10.
- OLMo-2 7B, general panel:
  `stage1-step93000-tokens391B` and
  `stage1-step928646-tokens3896B`; blocks 1, 15, and 30.

The retained full data comprise 1,161,216 token-by-condition records and
10,561,536 token-by-boundary propagation records over 252 prespecified windows.
There are 967,680 matched control records. The pilot passed 36/36 technical
and common-support strata; the full audit passed 126/126, with no numerical,
determinism, representation-matching, orthogonality, hook, or row-coverage
failure. The full matching diagnostics are in
`matching_validation.md`.

### Pythia natural versus controls

Common-support family means show a large generic longitudinal change in
attenuation:

| Family | Early mean A_hidden | Final mean A_hidden | Paired change (95% run bootstrap CI) |
|---|---:|---:|---:|
| Natural | -0.0380 | -1.2801 | -1.2421 [-1.4059, -1.0741] |
| Random orthogonal | -0.1393 | -1.2475 | -1.1082 [-1.2704, -0.9387] |
| Token permuted | -0.0824 | -1.3106 | -1.2282 [-1.3973, -1.0447] |

After the preregistered absolute-readout-projection adjustment:

| Checkpoint/contrast | Specificity | 95% run-bootstrap CI | prespecified materiality |
|---|---:|---:|---|
| Early, natural - random | +0.09660 | [+0.08940, +0.10818] | material |
| Early, natural - permuted | +0.04057 | [+0.02448, +0.05593] | nonmaterial: magnitude <0.05 |
| Early, natural - equal controls | +0.06859 | [+0.06270, +0.07374] | material |
| Final, natural - random | -0.03280 | [-0.05224, -0.01336] | nonmaterial: magnitude <0.05 |
| Final, natural - permuted | +0.02757 | [+0.01747, +0.03529] | nonmaterial: magnitude <0.05 |
| Final, natural - equal controls | -0.00261 | [-0.01555, +0.01002] | nonmaterial |
| Final - early, natural - random | -0.12940 | [-0.14496, -0.11247] | material |
| Final - early, natural - permuted | -0.01299 | [-0.03185, +0.00656] | nonmaterial |
| Final - early, natural - equal controls | -0.07120 | [-0.08746, -0.05460] | material |

At the early checkpoint, all six run-level natural-minus-random and
natural-minus-permuted estimates were positive: the natural direction was
less attenuated, not more attenuated, than either control on average. At the
final checkpoint, natural-minus-random was negative in five of six runs but
did not reach the prespecified 0.05 materiality threshold; natural-minus-permuted
remained positive in all six. The equal-control specificity decreased from
early to final in all six runs.

The longitudinal change was layer dependent. At block 1 the natural direction
was less attenuated than controls at both checkpoints (equal-control
specificity +0.2013 early and +0.1594 final). At block 5 the estimates were
smaller (+0.0489 and +0.0267). At block 10, equal-control specificity was
-0.0444 early and -0.1939 final. The final block-10 value combined a strongly
negative natural-minus-random contrast (-0.4373) with a positive
natural-minus-permuted contrast (+0.0495). Thus the deep-layer result did not
replicate across both preregistered control families.

### Readout adjustment and output-space results

The primary adjusted estimates were close to their unadjusted counterparts.
For example, equal-control specificity was +0.07244 unadjusted versus +0.06859
adjusted early, and -0.00271 versus -0.00261 final. Signed projection, absolute
and signed cosine, one-binary16-spacing exclusion, and leave-one-run-out
analyses preserved the same qualitative pattern. Each of the four random
seeds separately produced a positive early natural-minus-random estimate near
+0.10 and a negative final estimate near -0.032.

Continuous output specificity did not mirror greater hidden-state attenuation
of the natural direction. Adjusted `G_JS` natural-minus-equal-control was
+0.3329 early and +0.2725 final; adjusted `G_KL` was +0.3486 and +0.2647.
Natural perturbations therefore produced larger norm-standardized continuous
output divergence than controls at both checkpoints. Secondary NLL-change
specificity was +0.0568 early and +0.0795 final. These are robustness
descriptions and do not replace the hidden-state primary endpoint.

### Downstream localization and final normalization

No checkpoint passed the preregistered family-specific localization rule for
both control families in at least two layers. Qualifying isolated boundaries
occurred, but they did not form the H5 pattern.

The most pronounced separation was final Pythia block 10 at final
normalization. Its final-normalization contribution to specificity was
-0.5602 [-0.6965, -0.4335] against random controls and
-0.0669 [-0.0950, -0.0413] against permuted controls. After normalization,
the total block-10 specificity was -0.4373 against random but +0.0495 against
permuted. Final normalization therefore generated a large control-family
interaction rather than stable natural-direction attenuation relative to
every control family.

Other layers did not show the same pattern. At the final checkpoint, the
final-normalization contribution was +0.0414 against random and -0.0422
against permuted at block 1; at block 5 it was -0.0318 and +0.0578,
respectively.

### Held-out explanatory prediction

For Pythia, held-out `log(JS)` performance was:

| Model | Test R-squared | Test MAE |
|---|---:|---:|
| D1: magnitude/depth | 0.25356 | 0.71915 |
| D2: D1 + readout alignment | 0.25588 | 0.71781 |
| D3: D1 + propagation statistics | 0.35507 | 0.65113 |
| D4-noID: magnitude + alignment + propagation | 0.35705 | 0.65013 |
| D4: D4-noID + family identity | 0.36492 | 0.64446 |

The D2-minus-D1 increment was +0.00232
[+0.00189, +0.00277], below the prespecified +0.01 materiality threshold. The
D3-minus-D1 increment was +0.10146 [+0.09061, +0.11245] and material. The
family-identity D4-minus-D4-noID increment was +0.00783
[+0.00606, +0.00915], below the prespecified threshold. The full D4-minus-D3
increment was +0.00981 [+0.00788, +0.01137], also below the mean-effect
threshold.

### OLMo-2 7B descriptive cell

OLMo showed positive adjusted natural specificity at both checkpoints:

| Checkpoint/contrast | Specificity | Paired-window bootstrap interval |
|---|---:|---:|
| Early, natural - random | +0.47968 | [+0.47962, +0.47974] |
| Early, natural - permuted | +0.16287 | [+0.16281, +0.16293] |
| Final, natural - random | +0.30930 | [+0.30919, +0.30942] |
| Final, natural - permuted | +0.14406 | [+0.14397, +0.14415] |
| Final - early, natural - random | -0.17038 | [-0.17049, -0.17026] |
| Final - early, natural - permuted | -0.01882 | [-0.01890, -0.01873] |

These intervals describe prespecified-window variation within one released
trajectory; they are not independent-seed replication intervals. OLMo's
held-out R-squared values were 0.10035 (D1), 0.10151 (D2), 0.32137 (D3),
0.32225 (D4-noID), and 0.34070 (D4), descriptively.

## Interpretation

The data support a substantial generic longitudinal change in suffix
propagation: all three Pythia direction families became much more attenuated,
and generic propagation variables provided the largest held-out increment.
However, this generic component does not exhaust the data because early
natural-versus-random specificity was material and deep-layer effects depended
strongly on the control family.

The prespecified readout projection does not explain the mixed direction pattern.
It added little held-out value and adjustment barely changed specificity.
This weakens the tested H9 account, but it does not exclude direction geometry
outside the single preregistered top-token/runner-up unembedding contrast.

The deep final-layer/final-normalization result is not evidence for a stable
natural-specific process: it is strong relative to random directions but
absent, or opposite in sign, relative to token-permuted natural directions.
Accordingly, the stronger H5 language is not supported.

Hypothesis updates:

- **Generic propagation (H4) is not ruled out.** Generic propagation changes are large and predictive,
  but natural and controls do not propagate similarly enough for generic-propagation criterion.
- **Targeted compensation (H5) is weakened.** Natural attenuation was not greater than every control
  family, did not satisfy replicated multi-layer localization, and family
  identity added less than the prespecified held-out threshold.
- **The tested readout-alignment account (H9) is weakened.** The preregistered readout-alignment variables did not
  explain a material share of held-out output divergence and did not remove
  the observed family differences.
- **Joint local/downstream change (H3) is not ruled out.** The direction-control study does not contradict the representation-aware matched-perturbation study
  decomposition into changed local magnitude and changed suffix transfer.
- **Cross-family non-universality (U1) is not ruled out.** OLMo remains one descriptive trajectory; this assay does
  not supply replicated evidence sufficient to replace the prespecified
  cross-family non-universality conclusion.

