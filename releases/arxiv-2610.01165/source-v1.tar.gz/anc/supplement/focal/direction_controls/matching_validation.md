# The direction-control study representation-aware matching QC

Reader-oriented transcription of the retained pre-analysis record. Scientific definitions, thresholds and results are unchanged; administrative labels are expanded. This is not a new preregistration. References to raw acquisition artifacts describe separately retained records, not files promised in this summary export.


## Results

Across the 14 full preregistered cells, the assay retained 1,161,216
token-by-condition records and evaluated 967,680 control-direction matching
records.

- Matching passes: 967,680 / 967,680.
- Unexplained matching residual: maximum `0.0` under the prespecified representation-aware matching rule.
- Ideal random-direction orthogonality: maximum `3.1474514e-08`, below the
  preregistered `1e-5` tolerance.
- Executed-dtype random-direction orthogonality: maximum `0.007621214`, below
  the preregistered `0.01` tolerance.
- Deterministic repeat maximum logit difference: `0.0`.
- Beta-zero/no-op maximum logit difference: `0.0`.
- Natural/direct-identity maximum logit difference: `0.0`.
- Nonfinite readout projections: `0`.
- Probability-sum maximum absolute error: `1.3113022e-06`, below `1e-5`.
- Minimum raw KL/JS value observed: `1.5528344e-07`; no negative-divergence
  failure occurred.
- Full readout common-support criterion: 126 / 126 strata passed. Retained fractions
  ranged from `0.7020` to `0.9799`.

The outcome-blind pilot also passed all 36 preregistered layer/family strata;
retained common-support fractions ranged from `0.6901` to `0.9798`. Its natural
condition reproduced the validated the representation-aware matched-perturbation study intervention behavior on
the prespecified pilot subset.

## Interpretation

The observed scientific contrasts are not attributable to a recorded failure
of the representation-aware norm matcher, random-direction orthogonalizer,
deterministic intervention path, or readout common-support criterion.

## Unresolved interpretations

Passing these criteria does not establish that norm plus one readout projection
fully equates the geometry of natural and control perturbations. Richer local
Jacobian geometry remains unmeasured.
