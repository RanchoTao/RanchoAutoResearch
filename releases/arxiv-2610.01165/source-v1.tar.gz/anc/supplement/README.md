# Supplement index

`focal/` contains pre-analysis protocols, documented numerical revisions, validation records and processed summaries for the continuous-output, matched-perturbation and direction-control studies. Its README maps each result to the relevant files.

Released profiles and exported window-count arrays are in `../source/data/broad/`; historical replication inputs are in `../source/data/historical/`; recorded retrospective outputs are in `../source/results/`. Numerical exports omit benchmark text. Raw acquisition records and private execution records are retained separately and are not included.

Protocol hashes identify the original registered artifacts. The package-root checksum manifest verifies the reader-oriented copies in this export. The appendix is part of the manuscript compiled from the source-package root.
