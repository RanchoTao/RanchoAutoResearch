# Public ancillary material

This directory accompanies **Persistent Depth Ordering amid Shifting Block-Bypass Responses in Language Model Pretraining** by Shengye Tao, Yinzhu Cheng, and Haihua Xie.

## Contents

- `source/data/broad/`: complete 1,290-row block-profile table for 55 profiles across 11 model-domain combinations; repository/checkpoint manifest; context and source hashes; 35 window-count arrays in `window_counts.npz` (18 windows, 256 prediction positions per window).
- `source/data/historical/`: historical Hella and corrected WikiText-2 replication tables and recorded claims.
- `source/results/`: saved broad-profile, checkpoint-pair, rank-lag, cross-domain, window-bootstrap, split-window and trajectory-balanced summaries. `diagnostics/` contains separately labeled exploratory checks and does not add manuscript claims.
- `supplement/focal/`: reader-oriented copies of the continuous-output, matched-perturbation and direction-control protocols, amendments, implementation/environment notes, validation records, results and 43 processed CSV/JSON summaries. `CHECKPOINT_REFERENCES.csv` records the focal model revisions.
- `source/dense/data/`: numerical plotting inputs for the historical and released general-text dense figures. Portable `source` fields identify the released profile table and corresponding model panel; original checkpoint identifiers and scientific hashes are retained.
- `source/overview/fig1_empirical_base.pdf`: empirical vector input needed to compose the Figure 1 roadmap; it is a plotting input, not a duplicate manuscript PDF.
- `source/analysis/`, `source/dense/`, `source/overview/`: executable table validation, plotting, dense rendering and roadmap composition code. `source/requirements.txt` records the supplied dependency versions.
- `SHA256SUMS.txt`: SHA-256 of every other file under this ancillary directory. Protocol hashes identify original records; this manifest identifies the public exported copies.

The editable manuscript, bibliography, required styles, final tables and canonical vector figures are at the source-package root, outside `anc/`. There is no nested supplementary ZIP and no second manuscript tree.

## What can be reproduced

The profile table and exported window counts support the broad-profile point analyses and the six complete model-domain combinations used for window resampling. Saved outputs support the reported plots and table consistency checks without regenerating bootstrap intervals. Focal processed tables reproduce summary displays and permit consistency checks; they do not support full focal acquisition or raw model replay.

Work on a copy of the source package. From the package root:

```text
python anc/source/analysis/make_tables.py
python anc/source/analysis/plot_figures.py
python anc/source/dense/build_dense_figures.py
python anc/source/overview/build_overview.py
```

Table checks write `anc/generated/tables/` and `anc/validation/numerical_checks.json`. Panel plotting writes `anc/generated/figures/`; roadmap composition writes its Figure 1 there as well. The dense renderer writes local PDF/SVG/PNG displays and layout checks under `anc/source/dense/`. It also generates an optional persistence overview; that overview is not the manuscript's Figure 1. Final manuscript figures are never overwritten by these commands. The table generator covers the 11 external table fragments. Standalone panel plotting covers Figures 2-10; dense inputs cover Figures 11-12; roadmap composition supplies Figure 1. The original figure assets remain canonical.

`python anc/source/analysis/reanalyze_broad.py` optionally recomputes broad analyses, including bootstrap/partition outputs and exploratory diagnostics, and overwrites saved `anc/source/results/` in that copy. It was not run to produce this release. Broad reanalysis is retrospective, not preregistered.

## Protocol versions

- Continuous output: `supplement/focal/continuous_output/preanalysis_protocol.md`; the original count criterion and pre-outcome amendment are preserved in `reproducibility_revision.md`, with timing in `revision_timing.md` and checks in `numerical_validation.md`. Regression coefficients and leave-one-run-out results are in that study's `processed/smooth_model_coefficients.csv` and `processed/smooth_model_leave_one_run_out.csv`.
- Matched perturbations: `supplement/focal/matched_perturbations/preanalysis_protocol.md`, `protocol_revision.md`, `pilot_validation.md`, `matching_validation.md`, `environment.md` and `processed/`. Completed results use representation-aware actual post-cast norms; halted pilot outcomes are not substituted.
- Direction controls: `supplement/focal/direction_controls/preanalysis_protocol.md`, `pilot_validation.md`, `matching_validation.md`, `numerical_validation.md` and `processed/`. This control study does not identify targeted compensation.

These protocol copies are transcriptions of retained records, not new preregistrations. Model precision, numerical thresholds, seeds, original-record hashes and scientific limitations are preserved.

## Intentionally excluded

Model weights, benchmark text, raw token-level activations and token/boundary acquisition records, focal acquisition code, retained full experiment records and private execution provenance are not included. Historical tie handling and incomplete environment-lock information remain limitations stated in the manuscript. Saved uncertainty estimates were not regenerated during packaging. The anonymous conference manuscript tree, duplicate main-paper vector figures and old bundle manifests are omitted.
