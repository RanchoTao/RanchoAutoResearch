"""Evidence-dense vector views of existing response tensors.

Run prepare_data.py first. No inference, bootstrap, regression or smoothing.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.colors import Normalize, ListedColormap
from matplotlib.cm import ScalarMappable
from matplotlib.lines import Line2D
from PIL import Image

ROOT=Path(__file__).resolve().parent
(ROOT/'qa').mkdir(exist_ok=True)
H=json.loads((ROOT/'data/historical.json').read_text())
P=json.loads((ROOT/'data/released_general.json').read_text())
BLUE='#21658A'; ORANGE='#AE5826'; INK='#202A32'; GREY='#65717A'; LIGHT='#CBD3D9'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7,'axes.labelsize':7,
 'axes.titlesize':7.4,'xtick.labelsize':6.3,'ytick.labelsize':6.3,'axes.linewidth':.55,
 'axes.spines.top':False,'axes.spines.right':False,'xtick.major.width':.5,
 'ytick.major.width':.5,'xtick.major.size':2.5,'ytick.major.size':2.5,
 'text.color':INK,'axes.labelcolor':INK,'xtick.color':GREY,'ytick.color':GREY,
 'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'path','savefig.facecolor':'white'})
METADATA={}; LAYOUT={}
def ax(fig,rect,evidence=True):
    a=fig.add_axes(rect)
    if evidence:fig._data_axes.append(a)
    return a
def start(h,title):
    f=plt.figure(figsize=(5.5,h));f._data_axes=[]
    f.text(.025,.991,title,fontsize=9,weight='bold',va='top')
    return f
def head(f,x,y,label,text):f.text(x,y,f'{label}  {text}',weight='bold',fontsize=7.5,va='bottom')
def blank(a):
    for s in a.spines.values():s.set_visible(False)
    a.tick_params(length=0)
def cb(f,rect,cmap,vmin,vmax,label,ticks,orientation='horizontal'):
    c=f.colorbar(ScalarMappable(norm=Normalize(vmin,vmax),cmap=cmap),cax=ax(f,rect,False),orientation=orientation,ticks=ticks)
    c.solids.set_rasterized(False)
    c.solids.set_edgecolor('face')
    c.outline.set_visible(False);c.ax.tick_params(labelsize=6,length=2,pad=1)
    if orientation=='vertical':c.ax.set_title(label,fontsize=6.2,pad=3)
    else:c.set_label(label,fontsize=6.5,labelpad=2)
    return c
def matrix(a,m,vmin,vmax,cmap='viridis',annot=False,fmt='.1f',fontsize=6.5):
    m=np.array(m,dtype=float)
    if np.isnan(m).any():a.set_facecolor('#E6EAED')
    im=a.pcolormesh(np.arange(m.shape[1]+1)-.5,np.arange(m.shape[0]+1)-.5,
       np.ma.masked_invalid(m),cmap=cmap,vmin=vmin,vmax=vmax,edgecolors='white',linewidth=.25,rasterized=False)
    a.set(xlim=(-.5,m.shape[1]-.5),ylim=(m.shape[0]-.5,-.5));blank(a)
    if annot:
        for i,j in np.ndindex(m.shape):
            if np.isfinite(m[i,j]):
                color='white' if (m[i,j]-vmin)/(vmax-vmin)<.48 else INK
                a.text(j,i,format(m[i,j],fmt),ha='center',va='center',fontsize=fontsize,color=color)
    return im
def save(f,name,counts):
    f.canvas.draw(); renderer=f.canvas.get_renderer();bad=[]
    for t in f.findobj(matplotlib.text.Text):
        if t.get_visible() and t.get_text():
            bb=t.get_window_extent(renderer)
            if bb.x0<-.6 or bb.y0<-.6 or bb.x1>f.bbox.width+.6 or bb.y1>f.bbox.height+.6:
                bad.append(t.get_text())
    # Union of evidence-axis rectangles on a 2000 x 2000 occupancy grid.
    occupied=np.zeros((2000,2000),bool)
    for a in f._data_axes:
        b=a.get_position();occupied[int(b.y0*2000):int(b.y1*2000),int(b.x0*2000):int(b.x1*2000)]=True
    counts['evidence_axis_canvas_fraction']=round(float(occupied.mean()),4)
    # Include meaningful labels/annotations as a second, explicitly geometric proxy.
    annotated=occupied.copy()
    for t in f.findobj(matplotlib.text.Text):
        if t.get_visible() and t.get_text():
            b=t.get_window_extent(renderer).transformed(f.transFigure.inverted())
            annotated[max(0,int(b.y0*2000)):min(2000,int(b.y1*2000)),max(0,int(b.x0*2000)):min(2000,int(b.x1*2000))]=True
    counts['evidence_and_annotation_canvas_fraction']=round(float(annotated.mean()),4)
    counts['dimensions_inches']=list(f.get_size_inches());METADATA[name]=counts
    LAYOUT[name]={'text_outside_canvas':bad,'dimensions_inches':list(f.get_size_inches())}
    f.savefig(ROOT/f'{name}.pdf',metadata={'Author':'','Title':name,'Creator':'Matplotlib'})
    f.savefig(ROOT/f'{name}.svg',metadata={'Creator':'Matplotlib'})
    f.savefig(ROOT/f'{name}.png',dpi=300)
    Image.open(ROOT/f'{name}.png').convert('L').save(ROOT/'qa'/f'{name}_grayscale.png')
    plt.close(f)

# FIGURE 1: real matrix and deterministic views, compact assay strip.
f=start(3.6,'A measured layer-by-checkpoint response field')
s=ax(f,[.025,.765,.95,.175],False);s.set(xlim=(0,1),ylim=(0,1));s.axis('off')
s.text(0,.95,'a  Same context, one bypass, unchanged downstream computation',weight='bold',fontsize=7.3)
def arrow(a,b,col=GREY):s.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','lw':.8,'color':col,'shrinkA':1,'shrinkB':1})
s.text(.00,.42,'Context',va='center');arrow((.115,.42),(.19,.42))
s.text(.20,.42,r'$h_\ell$',va='center',fontsize=9)
for yy,txt,c in [(.67,r'$h_\ell+\Delta_\ell(h_\ell)$',INK),(.17,r'$h_\ell$  (identity)',ORANGE)]:
    arrow((.25,.42),(.31,yy),c);s.text(.325,yy,txt,va='center',fontsize=8,color=c)
    arrow((.53,yy),(.57,yy),c);s.text(.59,yy,'Remaining blocks + head',fontsize=6.6,va='center')
    arrow((.87,yy),(.91,yy),c);s.text(.92,yy,'Top-1',fontsize=6.6,va='center')
f.text(.025,.738,r'$D_\ell(t)=\mathrm{mean}_i\,\mathbf{1}[\hat y_i\ne\hat y_i^{(-\ell)}]$     Teacher forcing; no adaptation',fontsize=7)
hm=100*np.array(H['Hella']['mean_matrix']); ranks=np.array(H['Hella']['pairwise']['rank'])
sel=(ranks<=2).astype(int)
f.text(.06,.682,'Pythia-160M / Hella: run-averaged across six training runs',fontsize=7,color=GREY)
head(f,.06,.643,'b','Response (%)');head(f,.375,.643,'c','Column mean')
head(f,.615,.643,'d','Layer ranks');head(f,.83,.643,'e','Bottom two')
a=ax(f,[.06,.16,.25,.46]);matrix(a,hm,0,70,annot=True,fontsize=6.6)
a.set(xticks=[0,1,2],xticklabels=['14k','72k','143k'],yticks=range(10),yticklabels=range(1,11),ylabel='Block identity')
c=ax(f,[.38,.36,.19,.26]);c.plot(np.array(H['Hella']['steps'])/1000,hm.mean(0),'o-',color=BLUE,lw=1.3,ms=3)
for i,(x,y) in enumerate(zip(np.array(H['Hella']['steps'])/1000,hm.mean(0))):
    c.annotate(f'{y:.2f}',(x,y),xytext=[(3,-11),(0,10),(-3,8)][i],
               textcoords='offset points',ha='left' if i==0 else 'right' if i==2 else 'center',fontsize=6.4)
c.set(xlim=(0,157),ylim=(25,42),xticks=[14,72,143],yticks=[25,30,35,40],xlabel='Step (thousands)',ylabel='Mean (%)')
f.text(.375,.213,r'$\bar D(t)=\frac{1}{10}\sum_\ell D_\ell(t)$',fontsize=8)
f.text(.375,.140,'Same 30 cells;\nthree derived views',fontsize=6.6,color=GREY)
a=ax(f,[.62,.16,.16,.46]);matrix(a,ranks,1,10,'Blues_r',annot=True,fmt='.0f')
a.set(xticks=range(3),xticklabels=['14k','72k','143k'],yticks=range(10),yticklabels=range(1,11))
a.tick_params(axis='x',labelsize=6.1);f.text(.62,.077,'1 = lowest response',fontsize=6.1,color=GREY)
a=ax(f,[.835,.16,.14,.46]);matrix(a,sel,0,1,ListedColormap(['#F0F3F5',BLUE]));
a.set(xticks=range(3),xticklabels=['14k','72k','143k'],yticks=range(10),yticklabels=range(1,11));a.tick_params(axis='x',labelsize=6.1)
for i,j in zip(*np.where(sel)):a.text(j,i,str(i+1),ha='center',va='center',color='white',fontsize=6.5)
f.text(.835,.077,'Filled = selected',fontsize=6.1,color=GREY)
cb(f,[.065,.082,.24,.012],'viridis',0,70,'Disagreement (%)',[0,35,70])
save(f,'fig1_dense',{'direct_response_cells':30,'underlying_run_response_cells':180,'derived_values':63,
 'dimensions':['block identity','checkpoint','response magnitude','rank','selection'],
 'note':'The run dimension is averaged and labeled, not displayed individually. Repeated ranks/selections are not new observations.'})

# FIGURE 2: every replicated response cell, not only the panel means.
f=start(6.0,'Pythia-160M replication at run, layer, and checkpoint resolution')
f.text(.025,.957,'Hella: 6 runs   |   Corrected WikiText-2: 5 runs   |   Three checkpoints per run',fontsize=7,color=GREY)
for j,(corpus,label) in enumerate([('Hella','Hella-derived text'),('WT2','Corrected WikiText-2')]):
    x=.065+j*.49;h=H[corpus];cube=100*np.array(h['cube']);mean=cube.mean(0)
    head(f,x,.915,chr(97+j),label)
    a=ax(f,[x,.724,.067,.158]);matrix(a,mean,0,70)
    a.set(xticks=[],yticks=[0,4,9],yticklabels=[1,5,10]);a.set_title('Mean',fontsize=6.5,pad=3)
    if j==0:a.set_ylabel('Block',labelpad=2)
    # Equal-sized individual-run strips with explicit gaps, no new checkpoints.
    gap=.007;w=.043;startx=x+.092
    for r,run in enumerate(h['runs']):
        a=ax(f,[startx+r*(w+gap),.724,w,.158]);matrix(a,cube[r],0,70)
        a.set(xticks=[],yticks=[]);a.set_title(str(run)+('*' if run in [6,8] else ''),fontsize=6.4,pad=3)
    f.text(x,.698,'Each strip: 14k, 72k, 143k',fontsize=6.3,color=GREY)
cb(f,[.30,.679,.40,.010],'viridis',0,70,'Disagreement (%) - common linear scale',[0,20,40,60,70])

head(f,.08,.606,'c','Early versus final: every run-block pair')
a=ax(f,[.085,.335,.365,.25]);a.plot([15,70],[15,70],color=GREY,lw=.8,ls='--',zorder=0)
for corpus,c,marker in [('Hella',BLUE,'o'),('WT2',ORANGE,'^')]:
    cube=100*np.array(H[corpus]['cube']);m=cube.mean(0)
    a.scatter(cube[:,:,0].ravel(),cube[:,:,-1].ravel(),s=9,facecolors='none',edgecolors=c,alpha=.50,lw=.6,marker=marker)
    a.scatter(m[:,0],m[:,-1],s=19,c=c,marker=marker,edgecolor='white',lw=.35,zorder=4)
a.text(50,47,r'$y=x$',fontsize=6.5,color=GREY)
a.set(xlim=(15,70),ylim=(15,70),xticks=[20,40,60],yticks=[20,40,60],xlabel='14k disagreement (%)',ylabel='143k disagreement (%)')
a.text(.03,.97,'Open: run-block\nFilled: run mean per block',transform=a.transAxes,va='top',fontsize=6.2)

head(f,.59,.606,'d','Paired change along depth')
a=ax(f,[.595,.335,.365,.25]);a.axhline(0,color=GREY,lw=.65)
for corpus,c,marker in [('Hella',BLUE,'o'),('WT2',ORANGE,'^')]:
    cube=100*np.array(H[corpus]['cube']);delta=cube[:,:,-1]-cube[:,:,0]
    for v in delta:a.plot(range(1,11),v,color=c,lw=.55,alpha=.28,marker=marker,ms=1.7)
    a.plot(range(1,11),delta.mean(0),color=c,lw=1.5,marker=marker,ms=2.5,label=corpus if corpus=='Hella' else 'WikiText-2')
a.set(xlim=(.5,10.5),ylim=(-1,21),xticks=[1,3,5,7,9,10],yticks=[0,5,10,15,20],xlabel='Block identity',ylabel='143k - 14k change (pp)')
a.legend(frameon=False,fontsize=6.5,loc='upper right',handlelength=1.4,borderpad=0)

head(f,.08,.263,'e','Checkpoint means retain run variation')
a=ax(f,[.085,.103,.365,.135]);steps=np.array(H['Hella']['steps'])/1000
for corpus,c,marker in [('Hella',BLUE,'o'),('WT2',ORANGE,'^')]:
    cube=100*np.array(H[corpus]['cube']);runmeans=cube.mean(1)
    for v in runmeans:a.plot(steps,v,color=c,lw=.65,alpha=.35)
    a.plot(steps,runmeans.mean(0),color=c,lw=1.6,marker=marker,ms=3)
a.set(xticks=[14,72,143],xlabel='Step (thousands)',ylim=(25,48),yticks=[25,35,45],ylabel='Mean (%)')

head(f,.59,.263,'f','Paired run-mean endpoint changes')
a=ax(f,[.595,.103,.365,.135]);a.axvline(0,color=GREY,lw=.65)
for j,(corpus,c) in enumerate([('Hella',BLUE),('WT2',ORANGE)]):
    h=H[corpus];y=1-j;d=h['run_delta_pp']
    for k,(run,v) in enumerate(zip(h['runs'],d)):
        a.scatter(v,y+.15+(.12 if k%2 else 0),s=15,facecolor=c if run in [6,8] else 'white',edgecolor=c,lw=.7)
    mean=np.mean(d);a.scatter(mean,y-.1,marker='D',s=18,color=c,zorder=4)
    if corpus=='Hella':
        lo,hi=h['frozen_intervals_pp']['endpoint'];a.errorbar(mean,y-.1,xerr=[[mean-lo],[hi-mean]],color=c,capsize=2,lw=.9)
    a.text(.5,y+.16,f'{len(d)}/{len(d)}',fontsize=6.5,color=c)
    a.text(12.35,y-.10,f'+{mean:.2f}',fontsize=6.5,color=c,ha='right',va='center')
a.set(xlim=(-.4,12.5),ylim=(-.35,1.55),yticks=[1,0],yticklabels=['Hella','WT2'],xticks=[0,4,8,12],xlabel='Change (pp)');a.spines['left'].set_visible(False)
f.text(.025,.030,'* Runs 6 and 8 are shared across text panels; filled circles in f. Diamonds: panel means.',fontsize=6.3,color=GREY)
f.text(.025,.011,'Hella 95% paired-run CI: [6.77, 8.85] pp. No WT2 CI. Layers are not independent training replications.',fontsize=6.3,color=GREY)
raw_cells=sum(np.asarray(v['cube']).size for v in H.values())
pair_count=sum(len(v['runs'])*len(v['blocks']) for v in H.values())
mean_cells=sum(np.asarray(v['mean_matrix']).size for v in H.values())
run_instances=sum(len(v['runs']) for v in H.values())
mean_pairs=sum(len(v['blocks']) for v in H.values())
total_marks=raw_cells+mean_cells+2*pair_count+2*mean_pairs+3*run_instances+6+run_instances+2
save(f,'fig2_dense',{'direct_run_response_cells':raw_cells,'run_mean_heatmap_cells':mean_cells,'run_block_endpoint_pairs':pair_count,
 'run_block_delta_points':pair_count,'unique_training_runs':len(set(H['Hella']['runs'])|set(H['WT2']['runs'])),'text_panel_run_instances':run_instances,
 'total_repeated_and_derived_marks':total_marks,'dimensions':['text panel','training run','block identity','checkpoint','response','paired change'],
 'note':'330 unique run-block-checkpoint measurements are directly visible; 702 counts repeated views too, never independent N.'})

# FIGURE 3: all 630 layer-checkpoint values; narrow empirical strips at actual progress.
f=start(4.9,'Five longitudinal response fields, no common temporal direction')
f.text(.025,.954,'One released trajectory per model; means above, full layerwise measurements below',fontsize=6.8,color=GREY)
xs=[.067+i*.175 for i in range(5)];w=.145
head(f,.025,.925,'a','Change in checkpoint mean (pp)')
for x,p in zip(xs,P):
    a=ax(f,[x,.720,w,.135]);change=100*(np.array(p['means'])-p['means'][0]);prog=100*np.array(p['progress']);c=ORANGE if change[-1]<0 else BLUE
    a.axhline(0,color=LIGHT,lw=.65);a.plot(prog,change,'o-',color=c,lw=1.1,ms=2)
    a.set(xlim=(0,108),ylim=(-3,8),yticks=[-2,0,4,8],xticks=[10,50,100]);a.tick_params(axis='x',labelbottom=False)
    if x!=xs[0]:a.tick_params(axis='y',labelleft=False)
    f.text(x,.895,p['model'].replace('SmolLM2-1.7B','SmolLM2 1.7B'),fontsize=6.8,weight='bold')
    f.text(x,.872,f'Initial {100*p["means"][0]:.3f}%',fontsize=6.2,color=GREY)
head(f,.025,.670,'b','Layer x checkpoint disagreement (%)')
for x,p in zip(xs,P):
    a=ax(f,[x,.302,w,.337]);m=100*np.array(p['matrix']);n=p['total_blocks'];depth=np.array(p['blocks'])/(n-1);prog=100*np.array(p['progress'])
    for j,xx in enumerate(prog):
        a.pcolormesh([xx-5,xx+5],np.r_[depth-.5/(n-1),depth[-1]+.5/(n-1)],m[:,j:j+1],
             cmap='viridis',vmin=0,vmax=100,edgecolors='none',rasterized=False)
    a.set(xlim=(0,108),ylim=(1,0),yticks=[0,.5,1],xticks=[10,50,100]);blank(a)
    if x!=xs[0]:a.tick_params(axis='y',labelleft=False)
    else:a.set_ylabel('Relative block depth',labelpad=3)
    a.text(.5,1.025,f'{len(p["blocks"])} blocks',ha='center',transform=a.transAxes,fontsize=6.2,color=GREY)
cb(f,[.943,.302,.012,.337],'viridis',0,100,'%',ticks=[0,25,50,75,100],orientation='vertical')
f.text(.49,.235,'Recorded within-stage progress (%)',ha='center',fontsize=6.7)
head(f,.025,.200,'c','Endpoint change from first sample (pp)')
a=ax(f,[xs[0],.075,xs[-1]+w-xs[0],.091]);a.axhline(0,color=GREY,lw=.7)
centers=[x+w/2 for x in xs];left=xs[0];right=xs[-1]+w
for center,p in zip(centers,P):
    xx=(center-left)/(right-left);d=p['endpoint_delta_pp'];c=ORANGE if d<0 else BLUE
    a.plot([xx,xx],[0,d],color=c,lw=1);a.scatter(xx,d,color=c,marker='v' if d<0 else 'o',s=16)
    a.annotate(f'{d:+.3f}',(xx,d),xytext=(0,4 if d>=0 else -10),textcoords='offset points',ha='center',fontsize=6.5,color=c)
a.set(xlim=(0,1),ylim=(-3,8),xticks=[],yticks=[0,8]);a.spines['bottom'].set_visible(False)
f.text(.025,.021,'Heatmap strips are observed checkpoints; gaps are unmeasured. OLMo progress refers to stage one.',fontsize=6.2,color=GREY)
f.text(.025,.003,'All heatmaps share a linear 0-100% scale. Relative depth = block index / (total blocks - 1).',fontsize=6.2,color=GREY)
save(f,'fig3_dense',{'direct_response_cells':sum(np.asarray(p['matrix']).size for p in P),'checkpoint_means':sum(len(p['progress']) for p in P),'endpoint_summaries':len(P),
 'total_repeated_and_derived_marks':sum(np.asarray(p['matrix']).size+len(p['progress'])+1 for p in P),'dimensions':['model','block depth','checkpoint/progress','absolute response','mean change'],
 'heatmap_range_percent':[0,100],'common_mean_change_ylim_pp':[-3,8],
 'note':'Five columns are five single trajectories, not five independent runs of a controlled model.'})

# FIGURE 4: pairwise temporal evidence, with no reverse-time reuse estimates.
f=start(6.6,'Temporal persistence across ordering, membership, and reuse cost')
f.text(.025,.958,'a-e: Pythia-160M / Hella, six-run mean profiles     f-g: released general-text trajectories',fontsize=6.5,color=GREY)
pw=H['Hella']['pairwise'];labels=['14k','72k','143k']
head(f,.067,.919,'a',r'Rank correspondence $\rho$')
a=ax(f,[.07,.717,.245,.181]);matrix(a,pw['spearman'],0,1,'viridis',True,'.2f',7)
a.set(xticks=range(3),xticklabels=labels,yticks=range(3),yticklabels=labels);a.tick_params(axis='x',labelrotation=35)

head(f,.403,.919,'b','Early / final responses')
a=ax(f,[.412,.717,.235,.181]);m=100*np.array(H['Hella']['mean_matrix'])
a.plot([20,65],[20,65],color=GREY,ls='--',lw=.65)
for i in range(10):
    c=BLUE if i+1 in [5,7] else ORANGE if i+1 in [8,9] else GREY
    a.scatter(m[i,0],m[i,-1],s=17,color=c,zorder=3)
    # Label only selection-relevant identities to avoid fabricated offsets in values.
    if i+1 in [5,7,8,9]:
        label_positions={5:(23,49),7:(22,24),8:(36,24),9:(44,33)}
        a.annotate(str(i+1),(m[i,0],m[i,-1]),xytext=label_positions[i+1],textcoords='data',color=c,fontsize=6.7,
                   arrowprops={'arrowstyle':'-','lw':.5,'color':c,'shrinkA':1,'shrinkB':2})
a.set(xlim=(20,65),ylim=(20,65),xticks=[20,40,60],yticks=[20,40,60],xlabel='14k response (%)',ylabel='143k response (%)');a.text(.03,.94,r'$\rho=0.867$',transform=a.transAxes,va='top',fontsize=6.6)

head(f,.761,.919,'c','Fixed-block ranks')
a=ax(f,[.79,.717,.166,.181]);matrix(a,pw['rank'],1,10,'Blues_r',True,'.0f',6.3)
for j,sets in enumerate(pw['selected']):
    for l in sets:a.add_patch(Rectangle((j-.5,l-1-.5),1,1,fill=False,edgecolor=ORANGE,lw=1.1))
a.set(xticks=range(3),xticklabels=labels,yticks=range(10),yticklabels=range(1,11));a.tick_params(axis='x',labelrotation=35)
f.text(.766,.665,'Outline: bottom two\n1 = lowest response',fontsize=6.1,color=GREY)

head(f,.067,.622,'d','Retained / selected')
a=ax(f,[.07,.443,.245,.160]);matrix(a,pw['retention_forward'],0,1,'Blues',False)
for i in range(3):
    for j in range(i,3):a.text(j,i,f'{round(pw["retention_forward"][i][j]*2)}/2',ha='center',va='center',fontsize=7,color='white' if pw['retention_forward'][i][j] else INK)
a.set(xticks=range(3),xticklabels=labels,yticks=range(3),yticklabels=labels)

head(f,.403,.622,'e','Forward reuse regret (pp)')
a=ax(f,[.412,.443,.235,.160]);matrix(a,pw['regret_pp_forward'],0,5,'YlOrBr',False)
for i in range(3):
    for j in range(i,3):a.text(j,i,f'{pw["regret_pp_forward"][i][j]:.2f}',ha='center',va='center',fontsize=7,color=INK)
a.set(xticks=range(3),xticklabels=labels,yticks=range(3),yticklabels=labels);a.tick_params(axis='y',labelleft=False)
f.text(.754,.588,'14k to 143k',weight='bold',fontsize=6.8)
f.text(.754,.559,'0.79 pp [0, 2.23]',fontsize=7.4)
a=ax(f,[.755,.486,.205,.043]);v=.78668;a.axvline(0,color=LIGHT,lw=.7)
a.errorbar(v,0,xerr=[[v],[2.22982-v]],fmt='o',color=INK,ms=3,capsize=2,lw=.9)
a.set(xlim=(-.1,2.65),ylim=(-1,1),yticks=[],xticks=[0,1,2]);a.spines['left'].set_visible(False)
f.text(.754,.431,'95% paired-run CI;\nboth sets reselected',fontsize=6.2,color=GREY)
f.text(.067,.399,'d-f: rows are sources, columns are targets. Gray reverse-time cells are not zeros; diagonal costs are zero.',fontsize=6.1,color=GREY)

head(f,.025,.366,'f','Every forward checkpoint-pair cost across released trajectories (pp)')
for x,p in zip(xs,P):
    a=ax(f,[x,.247,w,.096]);matrix(a,p['pairwise']['regret_pp_forward'],0,5,'YlOrBr',False)
    a.set(xticks=[0,2,4],xticklabels=['1','3','5'],yticks=[0,2,4],yticklabels=['1','3','5'])
    if x!=xs[0]:a.tick_params(axis='y',labelleft=False)
    a.set_title(p['model'].replace('SmolLM2-1.7B','SmolLM2 1.7B'),fontsize=6.2,pad=3)
    a.add_patch(Rectangle((3.5,-.5),1,1,fill=False,edgecolor=INK,lw=.8))
cb(f,[.95,.247,.011,.096],'YlOrBr',0,5,'pp',[0,5],orientation='vertical')
f.text(.067,.211,'Columns: target; rows: source. 1-5 index actual samples in Fig. 3. Outlined cell: first to final.',fontsize=6.1,color=GREY)

head(f,.025,.181,'g','Early-to-final comparison')
ys=np.arange(5)[::-1];a1=ax(f,[.325,.047,.155,.105]);a2=ax(f,[.564,.047,.145,.105]);a3=ax(f,[.791,.047,.168,.105])
for a in [a1,a2,a3]:a.set(ylim=(-.5,4.5),yticks=[]);a.spines['left'].set_visible(False)
a1.set(xlim=(0,1.6),xticks=[0,1]);a1.spines['bottom'].set_bounds(0,1)
a2.set(xlim=(0,1.6),xticks=[0,1]);a2.spines['bottom'].set_bounds(0,1)
a3.set(xlim=(-.12,4.5),xticks=[0,3]);a3.spines['bottom'].set_bounds(0,3)
for a,t in [(a1,r'Rank $\rho$'),(a2,'Retained / selected'),(a3,'Regret (pp)')]:a.set_title(t,fontsize=6.5,pad=4)
for y,p in zip(ys,P):
    pw2=p['pairwise'];rho=pw2['spearman'][0][-1];ret=pw2['retention_forward'][0][-1];cost=pw2['regret_pp_forward'][0][-1];k=pw2['k']
    f.text(.027,.047+(y+.5)/5*.105,p['model'],va='center',fontsize=6.6)
    a1.scatter(rho,y,s=11,color=BLUE);a1.text(1.1,y,f'{rho:.3f}',va='center',fontsize=6.4)
    a2.plot([0,ret],[y,y],color=LIGHT,lw=1.1);a2.scatter(ret,y,s=13,color=BLUE,marker='s');a2.text(1.10,y,f'{round(ret*k)}/{k}',va='center',fontsize=6.4)
    a3.plot([0,cost],[y,y],color=LIGHT,lw=1.1);a3.scatter(cost,y,s=11,color=INK);a3.text(cost+.28,y,f'{cost:.3f}',va='center',fontsize=6.2)
f.text(.025,.010,'Costs compare separate single-block bypasses, not joint pruning or task loss. Released panels have no run-level CIs.',fontsize=6.1,color=GREY)
save(f,'fig4_dense',{'hella_response_pairs':10,'hella_rank_cells':30,'hella_correlation_cells':9,
 'hella_forward_retention_cells_with_diagonal':6,'hella_forward_regret_cells_with_diagonal':6,
 'released_forward_regret_cells':50,'released_regret_diagonal_cells':25,'released_endpoint_metric_values':15,
 'total_repeated_and_derived_marks':152,'underlying_run_response_cells':180,'underlying_released_response_cells':630,
 'dimensions':['block identity','source checkpoint','target checkpoint','rank','selection retention','reuse cost','model'],
 'note':'Pairwise cells are correlated views of the same trajectories. Regret CI adds one existing interval; no new resampling.'})
(ROOT/'qa/DENSITY.json').write_text(json.dumps(METADATA,indent=2)+'\n')
(ROOT/'qa/LAYOUT_CHECK.json').write_text(json.dumps(LAYOUT,indent=2)+'\n')
print(json.dumps(LAYOUT,indent=2))
