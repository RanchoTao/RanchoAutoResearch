"""Compose a vector roadmap above unchanged empirical Figure 1 panels.

No measurements, statistics or other figures are regenerated. Run with Python,
reportlab and pypdf. The local baseline PDF remains unchanged.
"""
from pathlib import Path
from io import BytesIO
import json

from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.pdfbase.pdfmetrics import stringWidth
from pypdf import PdfReader, PdfWriter
from pypdf.generic import RectangleObject

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
WIDTH, HEIGHT = 396, 356
EMPIRICAL_TOP = 185
INK = '#202A32'
BLUE = '#21658A'
ORANGE = '#AE5826'
GREY = '#65717A'
LIGHT = '#D3DBE0'

buf = BytesIO()
c = canvas.Canvas(buf, pagesize=(WIDTH, HEIGHT), invariant=1)
bounds = []


def text(x, y, content, size=7.1, bold=False, color=INK):
    font = 'Helvetica-Bold' if bold else 'Helvetica'
    width = stringWidth(content, font, size)
    assert 0 <= x and x + width <= WIDTH, content
    assert EMPIRICAL_TOP < y < HEIGHT - size, content
    bounds.append({'text': content, 'x': x, 'y': y, 'size': size, 'width': width})
    c.setFillColor(HexColor(color))
    c.setFont(font, size)
    c.drawString(x, y, content)


def box(x, y, w, h, fill='#F4F7F9', stroke=LIGHT):
    c.setFillColor(HexColor(fill))
    c.setStrokeColor(HexColor(stroke))
    c.setLineWidth(.55)
    c.roundRect(x, y, w, h, 3, stroke=1, fill=1)


def arrow(x0, y, x1, color=GREY):
    c.setStrokeColor(HexColor(color))
    c.setLineWidth(.65)
    c.line(x0, y, x1, y)
    c.line(x1-3, y+1.8, x1, y)
    c.line(x1-3, y-1.8, x1, y)


text(10, 342, 'a  Measurement and paper roadmap', size=8.2, bold=True)
box(10, 301, 49, 31)
text(15, 320, 'Same fixed', size=7)
text(15, 310, 'context', size=7)
arrow(60, 316, 68)
box(70, 301, 88, 31)
text(76, 320, 'Intact block', bold=True)
text(76, 310, 'or identity bypass', color=ORANGE)
arrow(160, 316, 168)
box(170, 301, 92, 31)
text(176, 320, 'Same remaining', size=7)
text(176, 310, 'suffix + output head', size=7)
arrow(264, 316, 272)
box(274, 301, 112, 31)
text(280, 320, 'Output distributions', bold=True)
text(280, 310, 'Continuous + top-1 readouts', size=6.8)

text(10, 287, 'Local missing update', color=ORANGE)
arrow(82, 289, 101)
text(108, 287, 'Downstream propagation', color=BLUE)
arrow(191, 289, 210)
text(217, 287, 'Continuous divergence / discrete response')

box(10, 252, 376, 25, fill='#EDF3F7')
text(16, 267, 'Follow the checkpoint x depth response field:', bold=True)
text(16, 257, 'Response level  |  Depth ordering  |  Localized redistribution  |  Cross-domain recurrence')

box(10, 198, 119, 45)
text(16, 234, 'Continuous-output audit', bold=True)
text(16, 222, 'Fixed-margin conditioning', size=6.9)
text(16, 210, 'Effect persists beyond', size=6.6, color=BLUE)
text(16, 201, 'top-1 flips', size=6.6, color=BLUE)

box(139, 198, 119, 45)
text(145, 234, 'Matched perturbations', bold=True)
text(145, 224, 'Local magnitude vs', size=6.9)
text(145, 216, 'downstream response', size=6.9)
text(145, 208, 'Separates generation from', size=6.6, color=BLUE)
text(145, 200, 'suffix response', size=6.6, color=BLUE)

box(268, 198, 118, 45, fill='#FAF5EF')
text(274, 234, 'Direction controls', bold=True)
text(274, 224, 'Random-orthogonal +', size=6.9)
text(274, 216, 'token-permuted controls', size=6.9)
text(274, 208, 'Direction-dependent propagation;', size=6.6, color=ORANGE)
text(274, 200, 'no targeted compensation identified', size=6.6, color=ORANGE)

c.setStrokeColor(HexColor(LIGHT))
c.setLineWidth(.55)
c.line(10, 190, 386, 190)
c.save()

original = PdfReader(HERE/'fig1_empirical_base.pdf').pages[0]
original.cropbox = RectangleObject([0, 0, WIDTH, EMPIRICAL_TOP])
writer = PdfWriter()
page = writer.add_blank_page(width=WIDTH, height=HEIGHT)
page.merge_page(original)
page.merge_page(PdfReader(BytesIO(buf.getvalue())).pages[0])
writer.metadata = None
writer.add_metadata({'/Title': 'Measurement and paper roadmap with empirical response field'})
(ROOT/'generated/figures').mkdir(parents=True,exist_ok=True)
writer.write(ROOT/'generated/figures/fig1_dense.pdf')
(ROOT/'validation').mkdir(exist_ok=True)
(ROOT/'validation/overview_geometry.json').write_text(json.dumps({
    'width_pt': WIDTH, 'height_pt': HEIGHT,
    'preserved_empirical_region_pt': [0, 0, WIDTH, EMPIRICAL_TOP],
    'scale_of_original_panels': 1.0,
    'new_text_bounds': bounds,
    'minimum_new_font_size_pt': min(x['size'] for x in bounds),
    'method': 'Vector PDF composition; original empirical drawing commands retained under clipping; no resampling or rasterization.'
}, indent=2)+'\n', encoding='utf-8')
