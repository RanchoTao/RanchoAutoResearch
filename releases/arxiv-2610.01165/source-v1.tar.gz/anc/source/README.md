# Numerical and code export

`data/broad/` and `data/historical/` retain supplied numerical exports. `results/` retains supplied retrospective point summaries, bootstrap summaries and saved partition outputs. `results/diagnostics/` retains exploratory diagnostics; these are not used as additional paper claims.

Broad reanalysis is retrospective, not preregistered. The supplied point and uncertainty summaries are recorded outputs; no new resampling, partitioning or model inference was run during packaging; optional table consistency checks and display generation were executed in a disposable copy. Stored uncertainty outputs were not independently regenerated.

`analysis/` contains optional supplied reanalysis, plotting and table scripts with paths adapted to this package. `requirements.txt` records source-package dependencies; the release audit records the execution checks performed for this release. Reanalysis is unnecessary for a LaTeX build and would create new analysis outputs.

`dense/` retains the existing renderer and local numerical inputs. Optional render outputs go under that directory. It can also render an additional persistence overview that is not used in the manuscript. Canonical manuscript PDFs are in `../../figures/` at the source-package root. Generated plotting outputs are separate from those frozen assets. Historical tie handling and incomplete environment-lock information remain limitations documented in the appendix.

Controlled-study summaries are in `../supplement/focal/`. Model weights, raw token/boundary Parquet files, acquisition code and private execution records are excluded. This is not a complete computational replay bundle.

## Presentation overview

`overview/build_overview.py` composes the early roadmap using reportlab and pypdf. Its input `overview/fig1_empirical_base.pdf` is the original empirical figure. It retains the original empirical region at unit scale, replaces the former assay strip with a vector roadmap, and writes `../generated/figures/fig1_dense.pdf`. No numerical measurement or statistic is computed. Use this builder for the roadmap; the separate dense renderer supplies the other empirical figures.
