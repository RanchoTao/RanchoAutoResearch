"""Render manuscript figures from packaged numerical records.

Every panel is a standalone, single-axis chart; LaTeX assembles related panels.
Blue/red/green are the requested low-saturation scientific palette. Source paths
are relative to the package and no model inference is performed.
"""
from pathlib import Path
import json, math, io
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import MaxNLocator, PercentFormatter

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'generated/figures';OUT.mkdir(parents=True,exist_ok=True)
BROAD=ROOT/'source/data/broad'; FOCAL=ROOT/'supplement/focal'; RES=ROOT/'source/results'
BLUE='#3D79A8'; RED='#C86470'; GREEN='#429784'; INK='#28343D'; GREY='#A1ACB4'; LIGHT='#E7ECEF'
COL={'general':BLUE,'math':RED,'code':GREEN}; MARK={'general':'o','math':'^','code':'s'}
DOMS=['general','math','code']
MODELS=['OLMo-2-0425-1B','OLMo-2-1124-7B','SmolLM2-1.7B-intermediate-checkpoints']
NAMES={MODELS[0]:'OLMo-2 1B',MODELS[1]:'OLMo-2 7B',MODELS[2]:'SmolLM2'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.1,'axes.titlesize':8.6,
 'axes.labelsize':8.0,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'legend.fontsize':7.3,
 'axes.linewidth':.65,'lines.linewidth':1.45,'lines.markersize':3.4,
 'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':INK,
 'text.color':INK,'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK,
 'pdf.fonttype':42,'ps.fonttype':42,'savefig.facecolor':'white','figure.facecolor':'white'})
manifest=json.loads((BROAD/'manifest.json').read_text())
f=pd.read_csv(BROAD/'profiles.csv')
D={m['panel']:f[f.panel.eq(m['panel'])].pivot(index='checkpoint_index',columns='layer_zero_based',values='sensitivity').to_numpy() for m in manifest}
source_manifest={}
layout_checks=[]

def chart(w=2.68,h=1.94,left=.20,bottom=.25,right=.96,top=.83):
 fig=plt.figure(figsize=(w,h));ax=fig.add_axes([left,bottom,right-left,top-bottom]);
 ax.tick_params(length=2.6,width=.65,pad=2)
 ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
 ax.grid(axis='y',color=LIGHT,linewidth=.55,zorder=0)
 return fig,ax

def title(ax,s):ax.set_title(s,loc='left',fontweight='bold',pad=8)
def save(fig,name,sources):
 fig.canvas.draw()
 renderer=fig.canvas.get_renderer(); box=fig.bbox
 labels=[]
 for ax in fig.axes:
  labels += [ax.xaxis.label, ax.yaxis.label, ax.title, ax._left_title, ax._right_title, *ax.texts]
  legend=ax.get_legend()
  if legend is not None: labels += list(legend.get_texts())
 for text in labels:
  if not text.get_visible() or not text.get_text().strip(): continue
  b=text.get_window_extent(renderer)
  if b.x0 < box.x0-1 or b.y0 < box.y0-1 or b.x1 > box.x1+1 or b.y1 > box.y1+1:
   raise ValueError(f'Figure text exceeds canvas: {name}: {text.get_text()} bounds={b.bounds} canvas={box.bounds}')
 layout_checks.append({'figure':name,'status':'PASS','checked_text_artists':len(labels)})
 pdf_buffer=io.BytesIO()
 fig.savefig(pdf_buffer,format='pdf',metadata={'Title':name,'Author':None,'Creator':None,'CreationDate':None})
 (OUT/f'{name}.pdf').write_bytes(pdf_buffer.getvalue())
 fig.savefig(OUT/f'{name}.png',dpi=300)
 source_manifest[name]=['source/'+s if s.startswith(('data/','results/')) else s for s in sources];plt.close(fig)

# Figure 3: depth profiles and temporal correspondence.
for model,name,lab in [(MODELS[0],'profile_o1','a'),(MODELS[1],'profile_o7','b')]:
 arr=D[model];x=np.linspace(0,1,arr.shape[1]); fig,ax=chart(1.79,2.08,left=.26,right=.93,bottom=.23)
 for t,c,ls,label in [(0,BLUE,'-','First'),(2,GREEN,'--','Middle'),(4,RED,'-','Last')]:
  ax.plot(x,arr[t]*100,c=c,ls=ls,lw=1.25,label=label,alpha=.92)
 ax.set(xlim=(0,1),xlabel='Measured depth',ylabel='Disagreement (%)');ax.set_xticks([0,.5,1],['0','.5','1'])
 ax.legend(loc='upper right',frameon=False,handlelength=1.2,labelspacing=.18,borderaxespad=.05,fontsize=6.8)
 title(ax,f'{lab}  {NAMES[model]}');save(fig,name,['data/broad/profiles.csv'])
lag=pd.read_csv(RES/'checkpoint_pairs.csv');fig,ax=chart(1.79,2.08,left=.26,right=.93,bottom=.23)
for _,g in lag.groupby('panel'):
 q=g.groupby('lag').rho.median();ax.plot(q.index,q.values,c=BLUE,alpha=.17,lw=.9)
q=lag.groupby('lag').rho.median();ax.plot(q.index,q.values,c=BLUE,marker='o',lw=1.7,zorder=3)
ax.set(ylim=(.30,1.04),xlim=(.8,4.2),xlabel='Checkpoint lag',ylabel='Rank correlation');ax.set_xticks([1,2,3,4]);ax.set_yticks([.4,.6,.8,1.0])
for x,y in q.items():ax.annotate(f'{y:.3f}',(x,y),xytext=(7 if x==1 else 0,6),textcoords='offset points',ha='center',fontsize=6.8)
title(ax,'c  Rank persistence');save(fig,'lag_memory',['results/checkpoint_pairs.csv'])

# Figure 4: cumulative concentration and genuine held-out selection.
fig,ax=chart(2.68,2.17,left=.23,bottom=.24);grid=np.linspace(0,1,201); curves=[]
for arr in D.values():
 v=np.sort(np.abs(arr[-1]-arr[0]))[::-1];x=np.arange(len(v)+1)/len(v);y=np.r_[0,np.cumsum(v)/v.sum()]
 ax.plot(x,y,color=BLUE,alpha=.19,lw=.85);curves.append(np.interp(grid,x,y))
med=np.median(curves,axis=0);ax.fill_between(grid,grid,med,color=BLUE,alpha=.08);ax.plot(grid,med,color=BLUE,lw=1.9)
ax.plot([0,1],[0,1],'--',color=GREY,lw=1.0);ax.axvline(.2,c=GREY,lw=.6,ls=':')
ax.set(xlim=(0,1),ylim=(0,1.04),xlabel='Fraction of measured blocks',ylabel='Share of absolute change')
ax.xaxis.set_major_formatter(PercentFormatter(1,decimals=0));ax.yaxis.set_major_formatter(PercentFormatter(1,decimals=0));ax.set_xticks([0,.2,.5,1]);ax.set_yticks([0,.5,1])
title(ax,'a  Concentrated changes');save(fig,'change_concentration',['data/broad/profiles.csv'])
split=pd.read_csv(RES/'split_window_validation.csv'); fig,ax=chart(2.68,2.17,left=.27,bottom=.24)
rows=[]
for model,short in [(MODELS[0],'O1'),(MODELS[2],'S')]:
 for dom in DOMS:
  pid=model+('' if dom=='general' else '__'+dom);g=split[split.panel.eq(pid)]
  vals=g.heldout_change_share; rows.append((short,dom,vals.median(),vals.quantile(.05),vals.quantile(.95),g.reference_share.iloc[0]))
for j,(short,dom,y,lo,hi,ref) in enumerate(rows):
 pos=len(rows)-1-j
 ax.hlines(pos,lo*100,hi*100,color=COL[dom],lw=2,alpha=.50)
 ax.scatter(y*100,pos,c=COL[dom],marker=MARK[dom],s=21,zorder=3)
 ax.vlines(ref*100,pos-.20,pos+.20,color=GREY,lw=1.5)
ax.set_yticks(np.arange(6),[a+' / '+d[0].upper() for a,d,*_ in rows[::-1]])
ax.set(ylim=(-.6,5.7),xlim=(0,100),xlabel='Held-out change share (%)');ax.set_xticks([0,25,50,75,100]);ax.grid(False);ax.grid(axis='x',c=LIGHT,lw=.55)
title(ax,'b  Held-out hotspots');save(fig,'heldout_hotspots',['results/split_window_validation.csv'])

# Figure 3: redistribution in three evaluation domains.
for model,name,lab in zip(MODELS,['delta_o1','delta_o7','delta_smol'],'abc'):
 fig,ax=chart(1.79,2.10,left=.31,bottom=.25,right=.93)
 ax.axhline(0,color=GREY,lw=.7)
 for dom,ls in zip(DOMS,['-','--',':']):
  pid=model+('' if dom=='general' else '__'+dom);arr=D[pid];x=np.linspace(0,1,arr.shape[1]);dy=100*(arr[-1]-arr[0])
  ax.plot(x,dy,c=COL[dom],ls=ls,lw=1.35,alpha=.9,label=dom.capitalize())
 ax.set(xlim=(0,1),xlabel='Measured depth',ylabel='Change (pp)');ax.set_xticks([0,.5,1],['0','.5','1'])
 title(ax,f'{lab}  {NAMES[model]}');save(fig,name,['data/broad/profiles.csv'])
hd=pd.read_csv(RES/'heldout_domain.csv'); hb=pd.read_csv(RES/'heldout_bootstrap.csv');fig,ax=chart(5.50,1.75,left=.11,right=.98,bottom=.24,top=.79)
for i,model in enumerate(MODELS):
 for k,dom in enumerate(DOMS):
  x=i+(k-1)*.14;v=hd[(hd.model==model)&(hd.held_domain==dom)].iloc[0];w=hb[(hb.model==model)&(hb.held_domain==dom)]
  if len(w):
   w=w.iloc[0];ax.vlines(x,w.lower,w.upper,color=COL[dom],lw=1.25,alpha=.6)
   ax.plot(x,v.r,marker=MARK[dom],ms=4.5,color=COL[dom],ls='none')
  else:ax.plot(x,v.r,marker=MARK[dom],ms=4.5,color=COL[dom],mfc='white',mew=1.05,ls='none')
ax.set(xlim=(-.35,2.35),ylim=(.75,1.017),ylabel='Held-out Pearson $r$');ax.set_yticks([.8,.9,1.0]);ax.set_xticks([0,1,2],[NAMES[x] for x in MODELS]);
for dom in DOMS:ax.plot([],[],marker=MARK[dom],c=COL[dom],ls='none',label=dom.capitalize())
ax.legend(loc='upper right',bbox_to_anchor=(1.0,1.36),ncol=3,frameon=False,handlelength=.7,columnspacing=1.1)
title(ax,'d  Leave-one-domain-out transfer');save(fig,'domain_holdout',['results/heldout_domain.csv','results/heldout_bootstrap.csv'])

# Figure 4: accepted continuous-output, always separate from historical execution.
continuous=FOCAL/'continuous_output/processed'; means=pd.read_csv(continuous/'checkpoint_endpoint_means.csv')
fig,ax=chart(1.79,2.07,left=.29,right=.94,bottom=.25)
runvec=[]
for _,g in means[means.panel.eq('pythia_hella')].groupby('run'):
 vals=g.set_index('checkpoint').loc[['step14000','step143000'],'flip'].to_numpy()*100
 ax.plot([0,1],vals,c=GREY,alpha=.55,lw=.9);ax.scatter([0,1],vals,c=[BLUE,RED],s=10,alpha=.6);runvec.append(vals)
y=np.mean(runvec,axis=0);ax.plot([0,1],y,c=INK,lw=1.7);ax.scatter([0,1],y,c=[BLUE,RED],s=24,zorder=4)
ax.set(xlim=(-.2,1.2),ylim=(26.5,39.8),ylabel='Disagreement (%)');ax.set_xticks([0,1],['14k','143k']);ax.set_xlabel('Training step');title(ax,'a  Six paired runs');save(fig,'pythia_runs',['supplement/focal/continuous_output/processed/checkpoint_endpoint_means.csv'])
strata=pd.read_csv(continuous/'margin_stratum_summary.csv');g=strata[(strata.panel=='pythia_hella')&(strata.metric=='js')].sort_values('stratum')
fig,ax=chart(1.79,2.07,left=.29,right=.94,bottom=.25)
for key,c,mk in [('early',BLUE,'o'),('final',RED,'s')]:ax.plot(np.arange(1,6),g[key],c=c,marker=mk,lw=1.25,ms=2.8,label=key.capitalize())
ax.set(xlim=(.6,5.4),ylim=(.050,.145),xlabel='Fixed margin stratum',ylabel='JS');ax.set_xticks(range(1,6),['Q'+str(i) for i in range(1,6)]);ax.legend(frameon=False,loc='center right',fontsize=6.8,handlelength=1.1)
title(ax,'b  Margin strata');save(fig,'margin_js',['supplement/focal/continuous_output/processed/margin_stratum_summary.csv'])
layer=pd.read_csv(continuous/'layer_checkpoint_summary.csv');g=layer[(layer.panel=='pythia_hella')&(layer.metric=='js')].sort_values('block')
fig,ax=chart(1.79,2.07,left=.29,right=.94,bottom=.25)
for key,c in [('early',BLUE),('final',RED)]:ax.plot(g.block,g[key],c=c,marker='o',ms=2,lw=1.25,label=key.capitalize())
ax.set(xlim=(.6,10.4),ylim=(.02,.195),xlabel='Measured block',ylabel='JS');ax.set_xticks([1,5,10]);ax.text(.48,.90,'$\\rho=0.915$',transform=ax.transAxes,fontsize=7.1)
title(ax,'c  JS depth profile');save(fig,'continuous_profile',['supplement/focal/continuous_output/processed/layer_checkpoint_summary.csv'])

# Figure 5: actual relative magnitude and suffix response; these axes have distinct units.
matched_dir=FOCAL/'matched_perturbations/processed';runs=pd.read_csv(matched_dir/'run_level_effects.csv');matched=pd.read_csv(matched_dir/'matched_actual_norm_adjusted_run_effects.csv')
for name,lab,kind,ylabel in [('local_magnitude','a','natural_r_local','Local relative RMS'),('matched_response','b','matched','Matched JS divergence')]:
 fig,ax=chart(1.79,2.12,left=.30,bottom=.30,top=.83)
 for j,pan in enumerate(['pythia_hella','olmo7b_general']):
  g=matched[matched.panel.eq(pan)] if kind=='matched' else runs[(runs.panel==pan)&(runs.metric==kind)]
  x=np.array([0,.75])+j*1.8;vals=g[['early','final']].to_numpy()
  for v in vals:
   ax.plot(x,v,c=GREY,alpha=.45,lw=.85);ax.scatter(x,v,c=[BLUE,RED],s=11,alpha=.5)
  y=vals.mean(axis=0);ax.plot(x,y,c=INK,lw=1.65,ls='-' if j==0 else '--');ax.scatter(x,y,c=[BLUE,RED],s=25,marker='o' if j==0 else 's',zorder=4)
  ax.text(x.mean(),-.36,'Pythia' if j==0 else 'OLMo',transform=ax.get_xaxis_transform(),ha='center',fontsize=7.4)
 ax.set_xticks([0,.75,1.8,2.55],['Early','Final','Early','Final']);ax.set_xlim(-.2,2.75);ax.set_ylabel(ylabel)
 if kind=='matched':ax.set_ylim(0,.038);ax.set_yticks([0,.01,.02,.03])
 else:ax.set_ylim(.345,.665);ax.set_yticks([.4,.5,.6])
 title(ax,lab+'  '+('Local update' if kind!='matched' else 'Matched JS'))
 save(fig,name,['supplement/focal/matched_perturbations/processed/'+('run_level_effects.csv' if kind!='matched' else 'matched_actual_norm_adjusted_run_effects.csv')])
rob=pd.read_csv(matched_dir/'robustness_summary.csv');fig,ax=chart(1.79,2.12,left=.36,bottom=.30,top=.83)
for gam in [.25,.5,.75,1.0]:
 key='matched_js_gamma_'+str(gam).rstrip('0').rstrip('.')
 g=rob[rob.analysis.eq(key)]
 if not len(g):g=rob[rob.analysis.eq('matched_js_gamma_'+str(gam))]
 w=g.iloc[0];ax.errorbar(gam,w.estimate,yerr=[[w.estimate-w.ci_low],[w.ci_high-w.estimate]],fmt='o',color=RED,elinewidth=1.2,capsize=2,ms=4)
ax.axhline(0,c=GREY,lw=.8);ax.set(xlim=(.14,1.10),ylim=(-.016,.0048),xlabel=r'Target scale $\gamma$',ylabel=r'$\Delta$ matched JS');ax.set_xticks([.25,.5,.75,1]);title(ax,'c  Scale effect')
save(fig,'matched_scale',['supplement/focal/matched_perturbations/processed/robustness_summary.csv'])
zones=pd.read_csv(matched_dir/'propagation_zone_effects.csv');fig,ax=chart(2.68,2.11,left=.27,bottom=.26,top=.83)
zone_order=['immediate','early','middle','late','final_norm']
for pan,c,label,mk in [('pythia_hella',BLUE,'Pythia','o'),('olmo7b_general',GREEN,'OLMo','s')]:
 g=zones[zones.panel.eq(pan)].set_index('zone').loc[zone_order]
 v=g.delta.to_numpy() if 'delta' in g else g.estimate.to_numpy();ax.plot(range(5),v,color=c,marker=mk,ms=3,label=label)
 if pan=='pythia_hella':ax.errorbar(range(5),v,yerr=np.vstack([v-g.ci_low,g.ci_high-v]),fmt='none',color=c,elinewidth=1,capsize=2)
ax.axhline(0,c=GREY,lw=.7);ax.set(xlim=(-.2,4.2),ylim=(-.2,.016),ylabel=r'$\Delta$ relative RMS');ax.set_xticks(range(5),['Inject','Early','Middle','Late','Final\nnorm']);ax.legend(frameon=False,loc='lower left',fontsize=7,handlelength=1.3)
title(ax,'Suffix propagation');save(fig,'suffix_localization',['supplement/focal/matched_perturbations/processed/propagation_zone_effects.csv'])

# Appendix: specificity controls, displayed without collapsing families.
direction=FOCAL/'direction_controls/processed'; spec=pd.read_csv(direction/'adjusted_layer_specificity.csv')
for family,name,lab in [('random','direction_random','a'),('permuted','direction_permuted','b')]:
 fig,ax=chart(2.68,2.03,left=.29,bottom=.24)
 for t,c in [(0,BLUE),(1,RED)]:
  g=spec[(spec.panel=='pythia_hella')&(spec.checkpoint_final.astype(str)==str(t))&spec.contrast.eq('natural_minus_'+family)].sort_values('block')
  v=g.estimate.to_numpy();ax.errorbar(g.block,v,yerr=np.vstack([v-g.ci_low,g.ci_high-v]),c=c,fmt='o-',lw=1.3,ms=3,capsize=2,label='Early' if t==0 else 'Final')
 ax.axhline(0,c=GREY,lw=.8);ax.set_xticks([1,5,10]);ax.set_xlabel('Intervention block');ax.set_ylabel('Attenuation specificity');ax.legend(frameon=False,fontsize=7,loc='best')
 title(ax,lab+'  Natural $-$ '+family);save(fig,name,['supplement/focal/direction_controls/processed/adjusted_layer_specificity.csv'])

# Appendix temporal fields: one heatmap per model, four transitions within each domain.
cmap=LinearSegmentedColormap.from_list('muted_response',[BLUE,'#FAFBFC',RED])
for model,name in zip(MODELS,['field_o1','field_o7','field_smol']):
 arrays=[100*np.diff(D[model+('' if dom=='general' else '__'+dom)],axis=0) for dom in DOMS];mat=np.vstack(arrays);lim=float(np.max(np.abs(mat)))
 fig=plt.figure(figsize=(5.5,2.12));ax=fig.add_axes([.15,.17,.70,.69]);im=ax.imshow(mat,aspect='auto',cmap=cmap,vmin=-lim,vmax=lim,interpolation='nearest',extent=(.5,mat.shape[1]+.5,11.5,-.5))
 ax.set_yticks(range(12),[(dom[0].upper()+': ' if k==0 else '    ')+f'{k+1}→{k+2}' for dom in DOMS for k in range(4)],fontsize=7.1)
 ax.set_xticks([1,round(mat.shape[1]/2),mat.shape[1]]);ax.tick_params(length=0,pad=3);ax.set_xlabel('Measured block',fontsize=8)
 for y in [3.5,7.5]:ax.axhline(y,c='white',lw=2)
 title(ax,NAMES[model]+' · successive checkpoint changes')
 cb=fig.colorbar(im,cax=fig.add_axes([.89,.17,.025,.69]));cb.ax.tick_params(labelsize=7,length=2);cb.set_label(r'$\Delta$ disagreement (pp)',fontsize=7.5)
 save(fig,name,['data/broad/profiles.csv'])

# Appendix: endpoint affine examples, retaining both a strong and weak fit.
ps=pd.read_csv(RES/'panel_summary.csv')
for row,name,lab in [(ps.loc[ps.affine_r2.idxmin()],'affine_weak','a'),(ps.loc[ps.affine_r2.idxmax()],'affine_strong','b')]:
 arr=D[row.panel];x=np.arange(1,arr.shape[1]+1);a,b=arr[0]*100,arr[-1]*100;coef=np.polyfit(a,b,1);fit=np.polyval(coef,a)
 fig,ax=chart(2.68,1.97,left=.21,bottom=.25)
 ax.plot(x,b,c=RED,label='Observed last',lw=1.5);ax.plot(x,fit,c=BLUE,ls='--',label='Shift + scale of first',lw=1.35)
 ax.fill_between(x,b,fit,color=RED,alpha=.12);ax.set(xlabel='Measured block',ylabel='Disagreement (%)');ax.set_xticks([1,round(len(x)/2),len(x)])
 ax.legend(frameon=False,fontsize=7,handlelength=1.3);title(ax,lab+f'  Endpoint fit ($R^2={row.affine_r2:.2f}$)')
 save(fig,name,['data/broad/profiles.csv','results/panel_summary.csv'])
(OUT/'figure_sources.json').write_text(json.dumps(source_manifest,indent=2)+'\n')
(ROOT/'validation/figure_text_bounds.json').write_text(json.dumps(layout_checks,indent=2)+'\n')
print(f'Rendered {len(layout_checks)} empirical panels (PDF + PNG).')
