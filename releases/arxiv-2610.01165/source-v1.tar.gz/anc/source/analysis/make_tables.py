"""Validate packaged numerical summaries and generate the appendix tables.

Broad profiles are checked against saved per-window counts and independently
recomputed statistics. Focal checks compare processed tables, not raw model
inference. No acquisition or hypothesis decisions are rerun by this script.
"""
from pathlib import Path
import json, math
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, pearsonr
ROOT=Path(__file__).resolve().parents[2]
TAB=ROOT/'generated/tables';TAB.mkdir(parents=True,exist_ok=True)
RES=ROOT/'source/results'; F=ROOT/'supplement/focal'
checks=[]
def check(name,condition,detail=''):
 if not bool(condition): raise AssertionError(name+': '+detail)
 checks.append({'check':name,'status':'PASS','detail':detail})
def table(name,cols,rows,spec):
 s='\\begin{tabular}{@{}'+spec+'@{}}\n\\toprule\n'+' & '.join(cols)+r' \\'+'\n\\midrule\n'
 s+='\n'.join(' & '.join(row)+r' \\' for row in rows)
 s+='\n\\bottomrule\n\\end{tabular}\n'
 (TAB/(name+'.tex')).write_text(s)
short={'OLMo-2-0425-1B':'OLMo-2 1B','OLMo-2-1124-7B':'OLMo-2 7B','OLMo-2-1124-13B':'OLMo-2 13B','SmolLM2-1.7B-intermediate-checkpoints':'SmolLM2','pythia-1.4b':'Pythia 1.4B'}
manifest=json.loads((ROOT/'source/data/broad/manifest.json').read_text())
pf=pd.read_csv(ROOT/'source/data/broad/profiles.csv'); counts=np.load(ROOT/'source/data/broad/window_counts.npz')
ps=pd.read_csv(RES/'panel_summary.csv'); windows_checked=0
check('Broad coverage',len(manifest)==11 and len(pf)==1290 and pf.groupby(['panel','checkpoint_index']).ngroups==55)
for m in manifest:
 a=pf[pf.panel==m['panel']].pivot(index='checkpoint_index',columns='layer_zero_based',values='sensitivity').to_numpy()
 row=ps[ps.panel==m['panel']].iloc[0]
 check('Shape '+m['panel'],a.shape==(5,m['measured_blocks']))
 check('Endpoint rank '+m['panel'],np.isclose(spearmanr(a[0],a[-1]).statistic,row.endpoint_rho,atol=1e-12))
 check('Affine fit '+m['panel'],np.isclose(pearsonr(a[0],a[-1]).statistic**2,row.affine_r2,atol=1e-12))
 d=np.abs(a[-1]-a[0]);k=math.ceil(.2*len(d))
 check('Concentration '+m['panel'],np.isclose(np.sort(d)[-k:].sum()/d.sum(),row.concentration20,atol=1e-12))
 for t in m['raw_available']:
  w=counts[m['panel']+f'__t{t}'];check('Window reconstruction '+m['panel']+f'/{t}',w.shape==(len(d),18) and np.allclose(w.sum(axis=1)/4608,a[t],atol=1e-12));windows_checked+=1
check('Window coverage',windows_checked==35)
rows=[]
for _,w in ps.iterrows():
 rows.append([short[w.model]+' / '+w.domain[0].upper(),f'{100*w.mean_change:+.2f}',f'{w.endpoint_rho:.3f}',f'{w.affine_r2:.3f}',f'{100*w.concentration20:.1f}',f'{w.top_retention:.2f}',f'{w.bottom_retention:.2f}'])
table('broad_summary',['Panel',r'$\Delta\bar D$ (pp)',r'$\rho$',r'Affine $R^2$',r'$C_k$ (\%)','High','Low'],rows,'lrrrrrr')
# Disjoint-window replication summaries.
split=pd.read_csv(RES/'split_window_validation.csv'); wb=pd.read_csv(RES/'window_bootstrap.csv'); rows=[]
for _,w in ps.iterrows():
 g=split[split.panel==w.panel]
 if not len(g):continue
 gap=wb[(wb.panel==w.panel)&(wb.metric=='adj_minus_endpoint')].iloc[0]
 vals=g.heldout_change_share
 rows.append([short[w.model]+' / '+w.domain[0].upper(),f'{gap.estimate:.3f}',f'[{gap.lower:.3f}, {gap.upper:.3f}]',f'{100*vals.median():.1f}',f'[{100*vals.quantile(.05):.1f}, {100*vals.quantile(.95):.1f}]'])
table('window_validation',['Panel',r'$\bar\rho_{\rm adj}-\rho_{\rm end}$','95\\% interval','Share (\\%)','5--95\\% splits'],rows,'lrrrr')
# Same-window-budget identity comparison.
rows=[]
for _,w in ps.iterrows():
 g=split[split.panel==w.panel]
 if len(g):rows.append([short[w.model]+' / '+w.domain[0].upper()]+[f'{g[k].median():.2f}' for k in ['within_top','across_top','within_bottom','across_bottom']])
table('identity_controls',['Panel','High: within','High: across','Low: within','Low: across'],rows,'lrrrr')
# Cross-domain template values and measured-end trimming.
hd=pd.read_csv(RES/'heldout_domain.csv'); rows=[]
for _,w in hd.iterrows():rows.append([short[w.model],w.held_domain.capitalize(),f'{w.r:.3f}',f'{w.trimmed_r:.3f}'])
table('domain_transfer',['Trajectory','Held-out text','All measured','Trimmed ends'],rows,'llrr')
# Region shares.
rows=[]
for _,w in ps.iterrows():rows.append([short[w.model]+' / '+w.domain[0].upper()]+[f'{100*w[k]:.1f}' for k in ['shallow_mass','middle_mass','deep_mass','shallow_trimfirst']])
table('region_shares',['Panel','Shallow (\\%)','Middle (\\%)','Deep (\\%)','Shallow, trimmed (\\%)'],rows,'lrrrr')
# Focal continuous-output: summaries and depth rank checks.
e=pd.read_csv(F/'continuous_output/processed/endpoint_change_summary.csv')
ranks=pd.read_csv(F/'continuous_output/processed/layer_profile_comparison.csv')
layer=pd.read_csv(F/'continuous_output/processed/layer_checkpoint_summary.csv')
means=pd.read_csv(F/'continuous_output/processed/checkpoint_endpoint_means.csv')
metrics={'flip':'Top-1 disagreement','forward_kl':'Forward KL','js':'Jensen--Shannon','target_nll_change':'Target NLL change','logit_margin_loss':'Logit-margin loss'}
rows=[];rankrows=[]
for metric,label in metrics.items():
 p=e[(e.panel=='pythia_hella')&(e.metric==metric)].iloc[0];o=e[(e.panel=='olmo7b_general')&(e.metric==metric)].iloc[0]
 rows.append([label,f'{p.change:+.4f}',f'[{p.ci_low:.4f}, {p.ci_high:.4f}]',f'{o.change:+.4f}'])
 vals=[]
 for panel in ['pythia_hella','olmo7b_general']:
  g=layer[(layer.panel==panel)&(layer.metric==metric)].sort_values('block');value=ranks[(ranks.panel==panel)&(ranks.metric==metric)].iloc[0].early_final_spearman
  check('continuous-output depth rank '+panel+'/'+metric,np.isclose(spearmanr(g.early,g.final).statistic,value,atol=1e-10))
  ee=e[(e.panel==panel)&(e.metric==metric)].iloc[0]
  check('continuous-output mean '+panel+'/'+metric,np.isclose(g.early.mean(),ee.early,atol=1e-10) and np.isclose(g.final.mean(),ee.final,atol=1e-10))
  vals.append(f'{value:.3f}')
 rankrows.append([label]+vals)
table('continuous_endpoints',['Endpoint','Pythia change','95\\% run interval','OLMo change'],rows,'lrrr')
table('continuous_ranks',['Endpoint',r'Pythia $\rho$',r'OLMo $\rho$'],rankrows,'lrr')
# Matched-perturbation summaries.
h=pd.read_csv(F/'matched_perturbations/processed/heldout_performance.csv'); rows=[]
for mod,label in [('M1','Local magnitude'),('M2','Downstream propagation'),('M3','Magnitude + propagation'),('M4','Joint + checkpoint terms')]:
 p=h[(h.panel=='pythia_hella')&(h.model==mod)].iloc[0];o=h[(h.panel=='olmo7b_general')&(h.model==mod)].iloc[0]
 rows.append([label,f'{p.test_r2:.3f}',f'{o.test_r2:.3f}'])
table('decomposition_prediction',['Predictors',r'Pythia test $R^2$',r'OLMo test $R^2$'],rows,'lrr')
rob=pd.read_csv(F/'matched_perturbations/processed/robustness_summary.csv');rows=[]
for gamma in [.25,.5,.75,1.0]:
 key='matched_js_gamma_'+str(gamma).rstrip('0').rstrip('.');g=rob[rob.analysis==key]
 if len(g)==0:g=rob[rob.analysis=='matched_js_gamma_'+str(gamma)]
 w=g.iloc[0];rows.append([f'{gamma:.2f}',f'{w.estimate:+.6f}',f'[{w.ci_low:+.6f}, {w.ci_high:+.6f}]'])
table('matched_scales',[r'$\gamma$','Matched-JS change','95\\% run interval'],rows,'rrr')
# direction-control retains both control families and heterogeneous propagation.
spec=pd.read_csv(F/'direction_controls/processed/adjusted_specificity_effects.csv');rows=[]
for fam in ['random','permuted']:
 a=spec[(spec.panel=='pythia_hella')&(spec.contrast=='natural_minus_'+fam)&(spec.checkpoint_final=='0')].iloc[0]
 b=spec[(spec.panel=='pythia_hella')&(spec.contrast=='natural_minus_'+fam)&(spec.checkpoint_final=='1')].iloc[0]
 d=spec[(spec.panel=='pythia_hella')&(spec.contrast=='natural_minus_'+fam)&(spec.checkpoint_final=='final_minus_early')].iloc[0]
 rows.append(['Natural $-$ '+fam,f'{a.estimate:+.4f}',f'{b.estimate:+.4f}',f'{d.estimate:+.4f}',f'[{d.ci_low:+.4f}, {d.ci_high:+.4f}]'])
table('direction_specificity',['Contrast','Early','Final','Change','95\\% change interval'],rows,'lrrrr')
inc=pd.read_csv(F/'direction_controls/processed/heldout_increments.csv'); rows=[]
for key,label in [('geometry_D2_minus_D1','Readout projection'),('generic_D3_minus_D1','Generic propagation'),('identity_D4_minus_D4_noID','Direction-family identity')]:
 w=inc[(inc.panel=='pythia_hella')&(inc.increment==key)].iloc[0]
 rows.append([label,f'{w.estimate:.5f}',f'[{w.ci_low:.5f}, {w.ci_high:.5f}]'])
table('direction_prediction',['Added information',r'Test $R^2$ increment','95\\% run interval'],rows,'lrr')
(ROOT/'validation').mkdir(exist_ok=True)
(ROOT/'validation/numerical_checks.json').write_text(json.dumps({'scope':'Independent broad-summary checks and focal processed-table consistency; no raw focal model replay.','checks':checks},indent=2)+'\n')
print(f'{len(checks)} numerical checks passed; generated {len(list(TAB.glob("*.tex")))} tables.')
