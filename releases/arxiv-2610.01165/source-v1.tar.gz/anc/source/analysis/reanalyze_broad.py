"""Deterministic reanalysis of saved block-bypass measurements (no model inference).

All cross-checkpoint resampling is paired at the 257-token window level. Only
panels with all five per-window acquisitions receive endpoint bootstrap CIs.
The exploratory diagnostics are saved separately from the primary summaries.
"""
from __future__ import annotations
from itertools import combinations, permutations
from pathlib import Path
import json, math
import numpy as np
import pandas as pd
from scipy.stats import rankdata

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'source/results';OUT.mkdir(exist_ok=True)
DIAG=OUT/'diagnostics';DIAG.mkdir(exist_ok=True)
B=2000
SEED=20260925
rng=np.random.default_rng(SEED)

def corr(x,y):
    x=np.asarray(x,float); y=np.asarray(y,float)
    x=x-x.mean(axis=-1,keepdims=True);y=y-y.mean(axis=-1,keepdims=True)
    den=np.sqrt(np.sum(x*x,axis=-1)*np.sum(y*y,axis=-1))
    return np.divide(np.sum(x*y,axis=-1),den,out=np.full_like(den,np.nan),where=den>1e-15)

def rho(x,y):return corr(rankdata(x,axis=-1),rankdata(y,axis=-1))
def z(x):return (x-x.mean(axis=-1,keepdims=True))/x.std(axis=-1,keepdims=True)
def rms(x):return np.sqrt(np.mean(np.asarray(x)**2,axis=-1))
def retain(a,b,k,top):
    sign=-1 if top else 1
    ia=np.argsort(sign*a,axis=-1,kind='stable')[...,:k]
    ib=np.argsort(sign*b,axis=-1,kind='stable')[...,:k]
    return (ia[...,None]==ib[...,None,:]).any(axis=-1).sum(axis=-1)/k

def panel_metrics(D):
    L=D.shape[-1]; k=math.ceil(.2*L); a=D[...,0,:];b=D[...,-1,:];delta=b-a
    d0=delta-delta.mean(axis=-1,keepdims=True)
    # R^2 of the best affine fit is squared Pearson correlation (with intercept).
    rt=corr(a,b)**2
    # IMPORTANT: this is residual RMS after removing a uniform *shift*, not after affine fitting.
    uniform_residual_ratio=rms(d0)/rms(delta)
    energy=uniform_residual_ratio**2
    sortedabs=np.sort(np.abs(delta),axis=-1)[...,::-1]
    c20=sortedabs[...,:k].sum(axis=-1)/sortedabs.sum(axis=-1)
    # thirds are defined once on the measured interior, matching the original method.
    g1=math.ceil(L/3);g2=math.ceil(2*L/3)
    totals=np.abs(delta).sum(axis=-1)
    sh=np.abs(delta[...,:g1]).sum(axis=-1)/totals
    mid=np.abs(delta[...,g1:g2]).sum(axis=-1)/totals
    dep=np.abs(delta[...,g2:]).sum(axis=-1)/totals
    trimtot=np.abs(delta[...,1:]).sum(axis=-1)
    shtrim=np.abs(delta[...,1:g1]).sum(axis=-1)/trimtot
    # normalized position within the measured interior; not the whole architecture.
    x=np.linspace(0,1,L)
    centroid_a=np.sum(a*x,axis=-1)/a.sum(axis=-1)
    centroid_b=np.sum(b*x,axis=-1)/b.sum(axis=-1)
    peakdiff=np.abs(np.argmax(a,axis=-1)-np.argmax(b,axis=-1))/(L-1)
    # Keeping early bottom-k identities: final mean sensitivity, not joint pruning.
    ia=np.argsort(a,axis=-1,kind='stable')[...,:k]
    ib=np.argsort(b,axis=-1,kind='stable')[...,:k]
    regret=np.take_along_axis(b,ia,axis=-1).mean(axis=-1)-np.take_along_axis(b,ib,axis=-1).mean(axis=-1)
    adj=np.stack([rho(D[...,i,:],D[...,i+1,:]) for i in range(4)],axis=-1).mean(axis=-1)
    return dict(mean_early=a.mean(axis=-1),mean_final=b.mean(axis=-1),mean_change=delta.mean(axis=-1),
      endpoint_rho=rho(a,b),adjacent_rho=adj,adj_minus_endpoint=adj-rho(a,b),
      affine_r2=rt,uniform_residual_rms_ratio=uniform_residual_ratio,uniform_residual_energy=energy,
      concentration20=c20,shallow_mass=sh,middle_mass=mid,deep_mass=dep,shallow_trimfirst=shtrim,
      top_retention=retain(a,b,k,True),bottom_retention=retain(a,b,k,False),
      centroid_shift=np.abs(centroid_b-centroid_a),peak_shift=peakdiff,
      bottom_reuse_cost=regret,max_change=np.max(np.abs(delta),axis=-1),
      change_rms=rms(delta),centered_change_rms=rms(d0))

manifest=json.loads((ROOT/'source/data/broad/manifest.json').read_text())
frame=pd.read_csv(ROOT/'source/data/broad/profiles.csv')
win=np.load(ROOT/'source/data/broad/window_counts.npz')
panels={}
for m in manifest:
    pid=m['panel']; f=frame[frame.panel==pid]
    D=f.pivot(index='checkpoint_index',columns='layer_zero_based',values='sensitivity').to_numpy()
    p=dict(meta=m,D=D)
    if len(m['raw_available'])==5:
        p['W']=np.stack([win[f'{pid}__t{t}'] for t in range(5)],axis=0)/256
    panels[pid]=p

rows=[];lags=[];coarse=[];timeperms=[];pca=[]
for pid,p in panels.items():
    D=p['D'];m=p['meta'];L=D.shape[1]
    met=panel_metrics(D)
    rows.append(dict(panel=pid,model=m['model'],domain=m['domain'],L=L,k=math.ceil(.2*L),
                     **{k:float(v) for k,v in met.items()}))
    for i,j in combinations(range(5),2):
        lags.append(dict(panel=pid,model=m['model'],domain=m['domain'],i=i,j=j,lag=j-i,
            progress_gap=m['progress'][j]-m['progress'][i],rho=float(rho(D[i],D[j])),
            # The handoff's "normalized RMSE" divides by the mean, NOT z-normalization.
            mean_normalized_rmse=float(rms(D[i]/D[i].mean()-D[j]/D[j].mean())),
            z_normalized_rmse=float(rms(z(D[i])-z(D[j]))),
            top_retention=float(retain(D[i],D[j],math.ceil(.2*L),True)),
            bottom_retention=float(retain(D[i],D[j],math.ceil(.2*L),False))))
    # Same number of coarse bins in data and shuffled-depth baselines. Total variation
    # contracts mechanically on aggregation; compare spatially contiguous grouping with null.
    a,b=D[0]/D[0].sum(),D[-1]/D[-1].sum()
    for ng in [L, max(3,math.ceil(L/2)),max(3,math.ceil(L/4)),3]:
        groups=np.array_split(np.arange(L),ng)
        tv=.5*sum(abs((a-b)[g].sum()) for g in groups)
        null=[]
        for it in range(1000):
            per=rng.permutation(L)
            null.append(.5*sum(abs((a-b)[per[g]].sum()) for g in groups))
        coarse.append(dict(panel=pid,bins=ng,observed_tv=tv,null_median=float(np.median(null)),
            null_q025=float(np.quantile(null,.025)),null_q975=float(np.quantile(null,.975))))
    rr=np.corrcoef(rankdata(D,axis=1))
    ob=np.mean([rr[i,i+1] for i in range(4)])-rr[0,4]
    null=[]
    for perm in permutations(range(5)):
        null.append(np.mean([rr[perm[i],perm[i+1]] for i in range(4)])-rr[perm[0],perm[4]])
    timeperms.append(dict(panel=pid,observed_adj_endpoint_gap=ob,
        exact_time_order_p=float(np.mean(np.asarray(null)>=ob-1e-12))))
    centered=D-D.mean(axis=1,keepdims=True)
    centered-=centered.mean(axis=0,keepdims=True)
    ev=np.linalg.svd(centered,compute_uv=False)**2; ev/=ev.sum()
    pca.append(dict(panel=pid,pc1=ev[0],pc12=ev[:2].sum(),maximum_rank=4))

summary=pd.DataFrame(rows); summary.to_csv(OUT/'panel_summary.csv',index=False)
lagdf=pd.DataFrame(lags);lagdf.to_csv(OUT/'checkpoint_pairs.csv',index=False)
pd.DataFrame(coarse).to_csv(DIAG/'exploratory_coarsegrain_null.csv',index=False)
pd.DataFrame(timeperms).to_csv(DIAG/'time_order_null.csv',index=False)
pd.DataFrame(pca).to_csv(DIAG/'exploratory_pca.csv',index=False)

# Within-model cross-domain similarities, with two targeted spatial controls.
xd=[];held=[]
models=sorted({m['model'] for m in manifest})
for model in models:
    ps=sorted([p for p in panels.values() if p['meta']['model']==model],key=lambda p:p['meta']['domain'])
    if len(ps)!=3: continue
    for pa,pb in combinations(ps,2):
        da=pa['D'][-1]-pa['D'][0];db=pb['D'][-1]-pb['D'][0];L=len(da)
        ga=np.diff(pa['D'],axis=0);gb=np.diff(pb['D'],axis=0)
        residual_a=da.copy();residual_b=db.copy()
        for g in np.array_split(np.arange(L),3):
            residual_a[g]-=da[g].mean();residual_b[g]-=db[g].mean()
        # Drop the union of domains' largest-change k blocks; diagnostic, not independent selection.
        k=math.ceil(.2*L);drop=np.union1d(np.argsort(np.abs(da))[-k:],np.argsort(np.abs(db))[-k:])
        keep=np.setdiff1d(np.arange(L),drop)
        xd.append(dict(model=model,domain_a=pa['meta']['domain'],domain_b=pb['meta']['domain'],
          endpoint_r=float(corr(da,db)),endpoint_rho=float(rho(da,db)),
          trimmed_endpoint_r=float(corr(da[1:-1],db[1:-1])),
          third_centered_r=float(corr(residual_a,residual_b)),
          hotspot_removed_r=float(corr(da[keep],db[keep])),hotspot_removed_remaining=len(keep),
          field_r=float(corr(ga.ravel(),gb.ravel())),
          trimmed_field_r=float(corr(ga[:,1:-1].ravel(),gb[:,1:-1].ravel())),
          timing_r=float(corr(rms(ga),rms(gb)))))
    for test in ps:
        train=[p for p in ps if p is not test]
        delta_test=test['D'][-1]-test['D'][0]
        # Pearson evaluates shape transfer; target-domain scale and offset are not predicted.
        template=np.mean([z(p['D'][-1]-p['D'][0]) for p in train],axis=0)
        template_trim=np.mean([z((p['D'][-1]-p['D'][0])[1:-1]) for p in train],axis=0)
        fieldtemplate=np.mean([z(np.diff(p['D'],axis=0).ravel()) for p in train],axis=0)
        # residualize each interval across depth, removing interval-wide level changes
        fields=[]
        for p in train:
            f=np.diff(p['D'],axis=0);f-=f.mean(axis=1,keepdims=True);fields.append(z(f.ravel()))
        gtest=np.diff(test['D'],axis=0);gtest-=gtest.mean(axis=1,keepdims=True)
        held.append(dict(model=model,held_domain=test['meta']['domain'],r=float(corr(template,delta_test)),
         trimmed_r=float(corr(template_trim,delta_test[1:-1])),
         field_r=float(corr(fieldtemplate,np.diff(test['D'],axis=0).ravel())),
         centered_field_r=float(corr(np.mean(fields,axis=0),gtest.ravel()))))
xd=pd.DataFrame(xd);xd.to_csv(OUT/'cross_domain.csv',index=False)
held=pd.DataFrame(held);held.to_csv(OUT/'heldout_domain.csv',index=False)

# Comparison templates from other models, evaluated over a common grid *inside*
# measured architectural depth. This is descriptive, not a model-ID classifier benchmark.
crossmodel=[]
three=[mo for mo in models if sum(m['model']==mo for m in manifest)==3]
for mo1,mo2 in combinations(three,2):
    for dom in ['general','math','code']:
        p1=next(p for p in panels.values() if p['meta']['model']==mo1 and p['meta']['domain']==dom)
        p2=next(p for p in panels.values() if p['meta']['model']==mo2 and p['meta']['domain']==dom)
        for trim in [0,1]:
            values=[];xs=[]
            for p in [p1,p2]:
                L=p['D'].shape[1];x=np.arange(1,L+1)/(L+1);d=p['D'][-1]-p['D'][0]
                if trim:x=x[1:-1];d=d[1:-1]
                xs.append(x);values.append(d)
            grid=np.linspace(max(x[0] for x in xs),min(x[-1] for x in xs),100)
            a,b=[np.interp(grid,x,v) for x,v in zip(xs,values)]
            crossmodel.append(dict(model_a=mo1,model_b=mo2,domain=dom,trim=trim,r=float(corr(a,b))))
pd.DataFrame(crossmodel).to_csv(DIAG/'cross_model_descriptive.csv',index=False)

# Paired window bootstrap. The random window multiplicities are fixed over all
# checkpoints and blocks in a panel, independently sampled between distinct domains.
bootrows=[];bootDs={};splits=[];near_null=[]
for pid,p in panels.items():
    if 'W' not in p:continue
    W=p['W'];L=W.shape[1]; k=math.ceil(.2*L)
    w=rng.multinomial(18,np.full(18,1/18),size=B)/18
    Dboot=np.einsum('bw,tlw->btl',w,W)
    bootDs[pid]=Dboot
    bm=panel_metrics(Dboot); point=panel_metrics(p['D'])
    for key,vals in bm.items():
        bootrows.append(dict(panel=pid,metric=key,estimate=float(point[key]),
            lower=float(np.quantile(vals,.025)),upper=float(np.quantile(vals,.975)),replicates=B))
    # Split the 18 fixed windows into disjoint 9-window halves. Select the largest
    # endpoint changes in A; measure their absolute change share in B (and vice versa).
    for b in range(1000):
        perm=rng.permutation(18);aa=W[...,perm[:9]].mean(axis=-1);bb=W[...,perm[9:]].mean(axis=-1)
        da=aa[-1]-aa[0];db=bb[-1]-bb[0]
        ia=np.argsort(-np.abs(da),kind='stable')[:k];ib=np.argsort(-np.abs(db),kind='stable')[:k]
        heldshare=.5*(np.abs(db[ia]).sum()/np.abs(db).sum()+np.abs(da[ib]).sum()/np.abs(da).sum())
        # Noise-only endpoint under H0: exchange early/final labels independently per window,
        # but share the sign across blocks. Tests coherent paired change, not a generic random layer null.
        signs=rng.choice([-1,1],size=18)
        nullDelta=((W[-1]-W[0])*signs).mean(axis=-1)
        near_null.append(dict(panel=pid,replicate=b,change_rms=float(rms(nullDelta)),
             centered_change_rms=float(rms(nullDelta-nullDelta.mean()))))
        splits.append(dict(panel=pid,replicate=b,heldout_change_share=heldshare,reference_share=k/L,
            within_top=.5*(retain(aa[0],bb[0],k,True)+retain(aa[-1],bb[-1],k,True)),
            within_bottom=.5*(retain(aa[0],bb[0],k,False)+retain(aa[-1],bb[-1],k,False)),
            across_top=.5*(retain(aa[0],bb[-1],k,True)+retain(bb[0],aa[-1],k,True)),
            across_bottom=.5*(retain(aa[0],bb[-1],k,False)+retain(bb[0],aa[-1],k,False)),
            crosshalf_delta_r=float(corr(da,db))))
pd.DataFrame(bootrows).to_csv(OUT/'window_bootstrap.csv',index=False)
splitdf=pd.DataFrame(splits);splitdf.to_csv(OUT/'split_window_validation.csv',index=False)
pd.DataFrame(near_null).to_csv(DIAG/'paired_change_null.csv',index=False)

# Cross-domain CIs only for the two complete raw-window trajectories.
xdboot=[];hoboot=[]
for model in three:
    ps=[p for p in panels.values() if p['meta']['model']==model]
    if not all(p['meta']['panel'] in bootDs for p in ps):continue
    for pa,pb in combinations(ps,2):
        da=bootDs[pa['meta']['panel']]; db=bootDs[pb['meta']['panel']]
        vals=corr(da[:,-1]-da[:,0],db[:,-1]-db[:,0])
        xdboot.append(dict(model=model,domain_a=pa['meta']['domain'],domain_b=pb['meta']['domain'],
            estimate=float(corr(pa['D'][-1]-pa['D'][0],pb['D'][-1]-pb['D'][0])),
            lower=float(np.quantile(vals,.025)),upper=float(np.quantile(vals,.975))))
    for test in ps:
        train=[p for p in ps if p is not test]
        dv=bootDs[test['meta']['panel']];target=dv[:,-1]-dv[:,0]
        templates=[]
        for tr in train:
            bb=bootDs[tr['meta']['panel']];templates.append(z(bb[:,-1]-bb[:,0]))
        vals=corr(np.mean(templates,axis=0),target)
        estimate=held[(held.model==model)&(held.held_domain==test['meta']['domain'])].iloc[0].r
        hoboot.append(dict(model=model,held_domain=test['meta']['domain'],estimate=estimate,
            lower=float(np.quantile(vals,.025)),upper=float(np.quantile(vals,.975))))
pd.DataFrame(xdboot).to_csv(OUT/'cross_domain_bootstrap.csv',index=False)
pd.DataFrame(hoboot).to_csv(OUT/'heldout_bootstrap.csv',index=False)

# Primary family-balanced sensitivity check: average domains within trajectory,
# then summarize across the five trajectories (no pseudo-independent n=11 test).
bal=summary.groupby('model').mean(numeric_only=True)
bal.to_csv(OUT/'trajectory_balanced.csv')
bylag=lagdf.groupby('lag')[['rho','mean_normalized_rmse','z_normalized_rmse','top_retention','bottom_retention']].median()
bylag.to_csv(OUT/'lag_summary.csv')
report=dict(seed=SEED,bootstrap_replicates=B,
    medians=summary.select_dtypes('number').median().to_dict(),
    trajectory_balanced_medians=bal.median().to_dict(),
    lag_medians=bylag.to_dict(),crossdomain_medians=xd.select_dtypes('number').median().to_dict(),
    heldout_medians=held.select_dtypes('number').median().to_dict(),
    raw_complete_panels=len(bootDs),split_window_medians=splitdf.groupby('panel').median(numeric_only=True).to_dict(),
    notes=['All reported tests are descriptive or exploratory unless specifically labeled.',
      'No new inference, KL divergence, NLL, task accuracy, or training-seed replication was performed.',
      'Mean-normalized profile RMSE in the original handoff is NOT z-normalized RMSE.',
      'Top-k absolute-change concentration exceeds k/L by construction in-sample; held-out windows validate nontrivial concentration.',
      'Total variation contracts under coarse graining even for random groupings; that fact alone does not demonstrate a stability law.'])
(OUT/'analysis_summary.json').write_text(json.dumps(report,indent=2)+'\n')
print('Panel summaries:')
print(summary[['panel','endpoint_rho','affine_r2','concentration20','shallow_mass','top_retention','bottom_retention']].to_string(index=False))
print('\nLag summary:\n',bylag)
print('\nCross-domain:\n',xd.to_string(index=False))
print('\nHeld-out domains:\n',held.to_string(index=False))
print('\nSplit-window check:\n',splitdf.groupby('panel')[['heldout_change_share','crosshalf_delta_r','within_top','within_bottom','across_top','across_bottom']].median())

# Selection-threshold sensitivity: descriptive, not a search for a favorable cutoff.
thresholds=[]
for pid,p in panels.items():
    D=p['D']; L=D.shape[1]
    for fraction in [.10,.15,.20,.25,.30,.35,.40]:
        k=math.ceil(fraction*L)
        top=float(retain(D[0],D[-1],k,True));bottom=float(retain(D[0],D[-1],k,False))
        thresholds.append(dict(panel=pid,fraction=fraction,k=k,L=L,top=top,bottom=bottom,difference=top-bottom))
pd.DataFrame(thresholds).to_csv(DIAG/'retention_thresholds.csv',index=False)
